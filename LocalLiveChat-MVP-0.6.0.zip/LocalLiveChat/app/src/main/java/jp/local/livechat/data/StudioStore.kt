package jp.local.livechat.data

import android.content.Context
import jp.local.livechat.model.AvatarDesign
import jp.local.livechat.model.BuiltInCharacters
import jp.local.livechat.model.GenerationSettings
import jp.local.livechat.model.HairPreset
import jp.local.livechat.model.MotionSettings
import jp.local.livechat.model.OutfitPreset
import jp.local.livechat.model.StudioProject
import org.json.JSONObject

class StudioStore(context: Context) {
    private val preferences = context.getSharedPreferences("studio_project_v1", Context.MODE_PRIVATE)

    fun load(): StudioProject {
        val raw = preferences.getString(KEY_PROJECT, null) ?: return StudioProject()
        return runCatching { decode(JSONObject(raw)).normalized() }.getOrDefault(StudioProject())
    }

    fun save(project: StudioProject) {
        preferences.edit().putString(KEY_PROJECT, encode(project.normalized()).toString()).apply()
    }

    fun export(project: StudioProject): String = encode(project.normalized()).toString(2)

    fun import(raw: String): StudioProject = decode(JSONObject(raw)).normalized()

    private fun encode(project: StudioProject): JSONObject {
        val character = project.character
        return JSONObject().apply {
            put("format", "mavatar")
            put("version", 3)
            put("name", character.persona.name)
            put("age", character.persona.age)
            put("relationship", character.persona.relationship)
            put("tone", character.persona.tone)
            put("boundaries", character.persona.boundaries)
            put("intimacy", character.persona.intimacy)
            put("customSystemPrompt", character.persona.customSystemPrompt)
            put("speechRate", character.voice.speechRate.toDouble())
            put("pitch", character.voice.pitch.toDouble())
            put("preferredVoiceId", character.voice.preferredVoiceId ?: JSONObject.NULL)
            put("hairPreset", project.avatarDesign.hairPreset.name)
            put("hairColor", project.avatarDesign.hairColorArgb)
            put("hairAccent", project.avatarDesign.hairAccentArgb)
            put("eyeColor", project.avatarDesign.eyeColorArgb)
            put("outfitPreset", project.avatarDesign.outfitPreset.name)
            put("outfitColor", project.avatarDesign.outfitColorArgb)
            put("breath", project.motion.breathStrength.toDouble())
            put("sway", project.motion.swayStrength.toDouble())
            put("blink", project.motion.blinkSpeed.toDouble())
            put("mouth", project.motion.mouthStrength.toDouble())
            put("maxTokens", project.generation.maxTokens)
            put("temperature", project.generation.temperature.toDouble())
        }
    }

    private fun decode(json: JSONObject): StudioProject {
        val base = BuiltInCharacters.Meru
        val formatVersion = json.optInt("version", 1)
        val storedRate = json.optDouble("speechRate", base.voice.speechRate.toDouble()).toFloat()
        val storedPitch = json.optDouble("pitch", base.voice.pitch.toDouble()).toFloat()
        val storedMaxTokens = json.optInt("maxTokens", 160)
        val character = base.copy(
            persona = base.persona.copy(
                name = json.optString("name", base.persona.name),
                age = json.optInt("age", base.persona.age),
                relationship = json.optString("relationship", base.persona.relationship),
                tone = json.optString("tone", base.persona.tone),
                boundaries = json.optString("boundaries", base.persona.boundaries),
                intimacy = json.optInt("intimacy", base.persona.intimacy),
                customSystemPrompt = json.optString("customSystemPrompt", "")
            ),
            voice = base.voice.copy(
                speechRate = if (formatVersion < 2 && kotlin.math.abs(storedRate - 1.04f) < 0.01f) {
                    base.voice.speechRate
                } else {
                    storedRate
                },
                pitch = if (formatVersion < 2 && kotlin.math.abs(storedPitch - 1.12f) < 0.01f) {
                    base.voice.pitch
                } else {
                    storedPitch
                },
                preferredVoiceId = json.optString("preferredVoiceId")
                    .takeIf { it.isNotBlank() && it != "null" }
            )
        )
        val design = AvatarDesign(
            hairPreset = enumValue(json.optString("hairPreset"), HairPreset.SHORT_BOB),
            hairColorArgb = json.optLong("hairColor", AvatarDesign().hairColorArgb),
            hairAccentArgb = json.optLong("hairAccent", AvatarDesign().hairAccentArgb),
            eyeColorArgb = json.optLong("eyeColor", AvatarDesign().eyeColorArgb),
            outfitPreset = enumValue(json.optString("outfitPreset"), OutfitPreset.AQUA_STREET),
            outfitColorArgb = json.optLong("outfitColor", AvatarDesign().outfitColorArgb)
        )
        return StudioProject(
            character = character,
            avatarDesign = design,
            motion = MotionSettings(
                breathStrength = json.optDouble("breath", 0.55).toFloat(),
                swayStrength = json.optDouble("sway", 0.35).toFloat(),
                blinkSpeed = json.optDouble("blink", 0.55).toFloat(),
                mouthStrength = json.optDouble("mouth", 0.75).toFloat()
            ),
            generation = GenerationSettings(
                maxTokens = if (formatVersion < 2 && storedMaxTokens == 320) 160 else storedMaxTokens,
                temperature = json.optDouble("temperature", 0.85).toFloat()
            )
        )
    }

    private inline fun <reified T : Enum<T>> enumValue(value: String, fallback: T): T =
        runCatching { enumValueOf<T>(value) }.getOrDefault(fallback)

    private companion object {
        const val KEY_PROJECT = "active_project"
    }
}
