package jp.local.livechat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import jp.local.livechat.avatar.AvatarRenderState
import jp.local.livechat.data.ConversationStore
import jp.local.livechat.engine.ConversationEngine
import jp.local.livechat.engine.EngineStatus
import jp.local.livechat.model.BuiltInCharacters
import jp.local.livechat.model.AvatarDesign
import jp.local.livechat.model.ChatMessage
import jp.local.livechat.model.CharacterProfile
import jp.local.livechat.model.CharacterResponse
import jp.local.livechat.model.Emotion
import jp.local.livechat.model.GenerationSettings
import jp.local.livechat.model.MotionSettings
import jp.local.livechat.model.Speaker
import jp.local.livechat.speech.SpeechController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatApp(
    engine: ConversationEngine,
    store: ConversationStore,
    speech: SpeechController,
    speaking: Boolean,
    onChooseModel: () -> Unit,
    character: CharacterProfile = BuiltInCharacters.Meru,
    avatarDesign: AvatarDesign = AvatarDesign(),
    motionSettings: MotionSettings = MotionSettings(),
    generationSettings: GenerationSettings = GenerationSettings()
) {
    val messages = remember(character.id) {
        mutableStateListOf<ChatMessage>().apply {
            addAll(store.load(character.id).ifEmpty {
                listOf(ChatMessage(speaker = Speaker.CHARACTER, text = character.greeting))
            })
        }
    }
    var input by remember { mutableStateOf("") }
    var generating by remember { mutableStateOf(false) }
    var emotion by remember { mutableStateOf(Emotion.HAPPY) }
    var motion by remember { mutableStateOf("idle") }
    var persona by remember(character.persona) { mutableStateOf(character.persona) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val engineStatus by engine.status.collectAsState()
    val modelLoading = engineStatus is EngineStatus.Loading

    LaunchedEffect(character.voice) {
        speech.configure(character.voice)
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || generating || modelLoading) return
        input = ""
        messages += ChatMessage(speaker = Speaker.USER, text = text)
        store.save(messages, character.id)
        val requestHistory = messages.toList()
        val pendingReply = ChatMessage(speaker = Speaker.CHARACTER, text = "")
        messages += pendingReply
        generating = true
        scope.launch {
            val response = runCatching {
                engine.reply(requestHistory, persona, generationSettings) { delta ->
                    val index = messages.indexOfFirst { it.id == pendingReply.id }
                    if (index >= 0) {
                        messages[index] = messages[index].copy(text = messages[index].text + delta)
                    }
                }
            }.getOrElse {
                CharacterResponse(
                    speech = "ごめんなさい、返答の生成中にエラーが起きました。モデル設定を確認してね。",
                    emotion = Emotion.SAD,
                    motion = "troubled"
                )
            }
            emotion = response.emotion
            motion = response.motion
            persona = persona.copy(intimacy = (persona.intimacy + response.intimacyDelta).coerceIn(0, 100))
            val replyIndex = messages.indexOfFirst { it.id == pendingReply.id }
            if (replyIndex >= 0) messages[replyIndex] = messages[replyIndex].copy(text = response.speech)
            store.save(messages, character.id)
            speech.speak(response.speech)
            generating = false
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    val colors = character.theme
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(colors.primaryArgb),
            secondary = Color(colors.secondaryArgb),
            background = Color(colors.backgroundArgb),
            surface = Color(colors.surfaceArgb),
            onPrimary = Color(0xFF08232C),
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Color(colors.backgroundArgb),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("${persona.name} · ${persona.age}", color = Color.White)
                            Text(
                                when (val status = engineStatus) {
                                    EngineStatus.Demo -> "DEMO · 親密度 ${persona.intimacy}"
                                    is EngineStatus.Loading -> "読込中: ${status.modelName}"
                                    is EngineStatus.Ready -> "LOCAL: ${status.modelName} · 親密度 ${persona.intimacy}"
                                    is EngineStatus.Error -> "モデルエラー · DEMO利用可"
                                },
                                color = Color(colors.mutedTextArgb),
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    },
                    actions = {
                        OutlinedButton(onClick = onChooseModel, modifier = Modifier.padding(end = 8.dp)) {
                            Text("GGUF")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(colors.backgroundArgb))
                )
            }
        ) { padding ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .imePadding()
            ) {
                Box(Modifier.fillMaxWidth().weight(0.47f)) {
                    AvatarSurface(
                        AvatarRenderState(
                            emotion = emotion,
                            motion = motion,
                            speaking = speaking,
                            profile = character.avatar,
                            design = avatarDesign,
                            animation = motionSettings
                        ),
                        Modifier.fillMaxSize()
                    )
                    Text(
                        text = when (emotion) {
                            Emotion.SHY -> "ちょっと照れてる…"
                            Emotion.LOVING -> "そばにいたい気分"
                            Emotion.SAD -> "心配してる…"
                            Emotion.ANGRY -> "少し怒ってる"
                            else -> "ご主人さまを見てる"
                        },
                        color = Color.White.copy(alpha = 0.76f),
                        modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp)
                    )
                }

                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxWidth().weight(0.53f).padding(horizontal = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item { Spacer(Modifier.height(2.dp)) }
                    if (engineStatus is EngineStatus.Error) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF4B2836)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    "モデル: ${(engineStatus as EngineStatus.Error).message}",
                                    color = Color(0xFFFFC2D1),
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                    }
                    items(messages.filter { it.text.isNotEmpty() }, key = { it.id }) { MessageBubble(it, character) }
                    if (generating) item {
                        Text("${persona.name}が考えています…", color = Color(colors.primaryArgb), modifier = Modifier.padding(8.dp))
                    }
                    item { Spacer(Modifier.height(4.dp)) }
                }

                Row(
                    Modifier.fillMaxWidth().background(Color(colors.surfaceArgb)).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        placeholder = { Text(character.inputHint) },
                        modifier = Modifier.weight(1f),
                        maxLines = 4,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send() })
                    )
                    Button(
                        onClick = {
                            if (generating) engine.cancelGeneration() else send()
                        },
                        enabled = (input.isNotBlank() || generating) && !modelLoading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (generating) Color(0xFFB34D70) else Color(colors.userBubbleArgb)
                        )
                    ) { Text(if (generating) "停止" else "送信") }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage, character: CharacterProfile) {
    val isUser = message.speaker == Speaker.USER
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Card(
            modifier = Modifier.fillMaxWidth(0.84f),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) {
                    Color(character.theme.userBubbleArgb)
                } else {
                    Color(character.theme.characterBubbleArgb)
                }
            )
        ) {
            Text(message.text, color = Color.White, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
        }
    }
}
