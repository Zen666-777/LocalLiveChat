package jp.local.livechat.speech

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID
import jp.local.livechat.model.VoiceProfile

data class VoiceOption(
    val id: String,
    val label: String,
    val requiresNetwork: Boolean
)

class SpeechController(
    context: Context,
    private val onSpeakingChanged: (Boolean) -> Unit
) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var profile = VoiceProfile()
    private val _availableVoices = MutableStateFlow<List<VoiceOption>>(emptyList())
    val availableVoices = _availableVoices.asStateFlow()

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = onSpeakingChanged(true)
            override fun onDone(utteranceId: String?) = onSpeakingChanged(false)
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = onSpeakingChanged(false)
        })
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) {
            refreshAvailableVoices()
            applyVoiceProfile()
        }
    }

    fun configure(newProfile: VoiceProfile) {
        profile = newProfile
        if (ready) applyVoiceProfile()
    }

    private fun applyVoiceProfile() {
        tts.language = Locale.forLanguageTag(profile.localeTag)
        tts.setSpeechRate(profile.speechRate)
        tts.setPitch(profile.pitch)
        val japaneseVoices = tts.voices.orEmpty()
            .filter { it.locale.language == Locale.JAPANESE.language }
        val selected = profile.preferredVoiceId?.let { voiceId ->
            japaneseVoices.firstOrNull { it.name == voiceId }
        } ?: japaneseVoices
            .sortedWith(
                compareBy<android.speech.tts.Voice> { it.isNetworkConnectionRequired }
                    .thenByDescending { it.quality }
                    .thenBy { it.name }
            )
            .firstOrNull()
        selected?.let { tts.voice = it }
    }

    private fun refreshAvailableVoices() {
        _availableVoices.value = tts.voices.orEmpty()
            .filter { it.locale.language == Locale.JAPANESE.language }
            .sortedWith(
                compareBy<android.speech.tts.Voice> { it.isNetworkConnectionRequired }
                    .thenByDescending { it.quality }
                    .thenBy { it.name }
            )
            .mapIndexed { index, voice ->
                VoiceOption(
                    id = voice.name,
                    label = "日本語 ${index + 1}${if (voice.isNetworkConnectionRequired) "・通信" else "・端末内"}",
                    requiresNetwork = voice.isNetworkConnectionRequired
                )
            }
    }

    fun speak(text: String) {
        if (!ready) return
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), UUID.randomUUID().toString())
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
