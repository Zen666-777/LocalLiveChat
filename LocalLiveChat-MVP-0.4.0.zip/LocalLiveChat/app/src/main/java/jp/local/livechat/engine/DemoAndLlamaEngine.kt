package jp.local.livechat.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import jp.local.livechat.model.CharacterResponse
import jp.local.livechat.model.ChatMessage
import jp.local.livechat.model.Emotion
import jp.local.livechat.model.GenerationSettings
import jp.local.livechat.model.Persona

class DemoAndLlamaEngine : ConversationEngine {
    private val dispatcher = Dispatchers.IO.limitedParallelism(1)
    private val _status = MutableStateFlow<EngineStatus>(EngineStatus.Demo)
    override val status = _status.asStateFlow()

    override suspend fun loadModel(path: String, modelName: String): Result<Unit> = withContext(dispatcher) {
        _status.value = EngineStatus.Loading(modelName)
        runCatching {
            check(LlamaCppBridge.loadModel(path)) {
                LlamaCppBridge.lastError().ifBlank { "GGUFを読み込めませんでした" }
            }
            _status.value = EngineStatus.Ready(modelName)
        }.onFailure {
            _status.value = EngineStatus.Error(it.message ?: "モデル読込エラー")
        }
    }

    override suspend fun reply(
        history: List<ChatMessage>,
        persona: Persona,
        settings: GenerationSettings
    ): CharacterResponse = withContext(dispatcher) {
        if (_status.value !is EngineStatus.Ready) {
            return@withContext demoReply(history.lastOrNull()?.text.orEmpty())
        }

        val conversation = buildString {
            history.takeLast(8).forEach {
                append(if (it.speaker.name == "USER") "ユーザー: " else "${persona.name}: ")
                appendLine(it.text)
            }
        }
        val safeSettings = settings.normalized()
        val raw = LlamaCppBridge.generate(
            persona.systemPrompt(),
            conversation,
            safeSettings.maxTokens,
            safeSettings.temperature
        )
        if (raw.isBlank()) {
            val message = LlamaCppBridge.lastError()
            if (message.isBlank()) {
                return@withContext CharacterResponse(
                    speech = "……うん。ここで止めておきますね。",
                    emotion = Emotion.NEUTRAL,
                    motion = "idle"
                )
            }
            _status.value = EngineStatus.Error(message)
            return@withContext CharacterResponse(
                speech = "ごめんなさい、いま上手く考えられなかったみたい。モデル設定を確認してね。",
                emotion = Emotion.SAD,
                motion = "troubled"
            )
        }
        StructuredResponseParser.parse(raw)
    }

    private suspend fun demoReply(input: String): CharacterResponse {
        delay(420)
        return when {
            listOf("好き", "かわいい", "愛して").any(input::contains) -> CharacterResponse(
                "えへへ……そんなこと言われたら、もっとご主人さまのそばにいたくなっちゃいます。",
                Emotion.SHY,
                "look_away",
                2
            )
            listOf("疲れ", "しんど", "眠い").any(input::contains) -> CharacterResponse(
                "今日はよく頑張りましたね。ここでは力を抜いて、メルに甘えてください。",
                Emotion.LOVING,
                "lean_in",
                1
            )
            else -> CharacterResponse(
                "はい、ご主人さま。もっと聞かせてください。メル、ちゃんと覚えていたいです。",
                Emotion.HAPPY,
                "nod",
                1
            )
        }
    }

    override fun close() {
        LlamaCppBridge.cancel()
        LlamaCppBridge.unload()
        _status.value = EngineStatus.Demo
    }

    override fun cancelGeneration() = LlamaCppBridge.cancel()
}

private object LlamaCppBridge {
    init {
        System.loadLibrary("local_llm")
    }

    external fun loadModel(path: String): Boolean
    external fun generate(systemPrompt: String, conversation: String, maxTokens: Int, temperature: Float): String
    external fun cancel()
    external fun unload()
    external fun lastError(): String
}
