package jp.local.livechat.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import jp.local.livechat.R
import jp.local.livechat.avatar.AvatarRenderState
import jp.local.livechat.model.Emotion
import kotlin.math.PI
import kotlin.math.sin

/**
 * 確定イラストを使う軽量ポートレートアニメーター。
 * Live2Dモデル完成前でも、呼吸・揺れ・まばたき・発話差分を端末内だけで再生する。
 */
@Composable
fun AvatarSurface(state: AvatarRenderState, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "meru_portrait")
    val breathe by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(1900, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "breathe"
    )
    val sway by transition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(2800, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "sway"
    )
    val blinkPhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween((4200 - state.animation.blinkSpeed * 2300).toInt().coerceAtLeast(1500)),
            RepeatMode.Restart
        ),
        label = "blink"
    )
    val talkPhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(if (state.speaking) 145 else 900),
            RepeatMode.Reverse
        ),
        label = "talk"
    )

    val blinkAlpha = if (blinkPhase > 0.91f) {
        sin(((blinkPhase - 0.91f) / 0.09f * PI).toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val talkAlpha = if (state.speaking) {
        ((talkPhase - 0.24f) * 2.2f * state.animation.mouthStrength).coerceIn(0f, 1f)
    } else {
        0f
    }
    val motionTilt = when (state.motion) {
        "look_away" -> -0.8f
        "lean_in" -> 0.35f
        "troubled" -> -0.35f
        else -> 0f
    }
    val emotionGlow = when (state.emotion) {
        Emotion.SHY, Emotion.LOVING -> Color(0x44FF7FA8)
        Emotion.SAD -> Color(0x334D8FD1)
        Emotion.ANGRY -> Color(0x33FF5D6C)
        else -> Color(0x223EDCF2)
    }

    Box(
        modifier
            .clipToBounds()
            .background(Brush.verticalGradient(listOf(Color(0xFF10242D), Color(0xFF07151D))))
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val breathAmount = state.animation.breathStrength
                    scaleX = 1.01f + breathe * 0.006f * breathAmount
                    scaleY = 1.01f + breathe * 0.012f * breathAmount
                    translationX = sway * 5f * state.animation.swayStrength
                    translationY = -breathe * 3f * breathAmount
                    rotationZ = motionTilt + sway * 0.35f * state.animation.swayStrength
                }
        ) {
            Image(
                painter = painterResource(R.drawable.meru_idle),
                contentDescription = "メル",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter
            )
            if (talkAlpha > 0f) {
                Image(
                    painter = painterResource(R.drawable.meru_talk),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alignment = Alignment.TopCenter,
                    alpha = talkAlpha * (1f - blinkAlpha)
                )
            }
            if (blinkAlpha > 0f) {
                Image(
                    painter = painterResource(R.drawable.meru_blink),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alignment = Alignment.TopCenter,
                    alpha = blinkAlpha
                )
            }
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Transparent, emotionGlow)
                    )
                )
        )
    }
}
