package jp.local.livechat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import jp.local.livechat.avatar.AvatarRenderState
import jp.local.livechat.data.ConversationStore
import jp.local.livechat.engine.ConversationEngine
import jp.local.livechat.engine.EngineStatus
import jp.local.livechat.model.Emotion
import jp.local.livechat.model.HairPreset
import jp.local.livechat.model.InferenceMode
import jp.local.livechat.model.OutfitPreset
import jp.local.livechat.model.StudioProject
import jp.local.livechat.speech.SpeechController
import jp.local.livechat.speech.VoiceOption
import kotlin.math.roundToInt

private enum class StudioTab(val label: String) {
    CHAT("会話"), CHARACTER("キャラ"), MODEL("モデル"), MOTION("動き")
}

private data class VoicePreset(val label: String, val rate: Float, val pitch: Float)

private val voicePresets = listOf(
    VoicePreset("かわいい", 1.02f, 1.28f),
    VoicePreset("やわらか", 0.94f, 1.18f),
    VoicePreset("落ち着き", 0.90f, 1.04f)
)

@Composable
fun StudioApp(
    localEngine: ConversationEngine,
    cloudEngine: ConversationEngine,
    store: ConversationStore,
    speech: SpeechController,
    speaking: Boolean,
    project: StudioProject,
    modelImporting: Boolean,
    cloudApiKeyConfigured: Boolean,
    onProjectChange: (StudioProject) -> Unit,
    onChooseModel: () -> Unit,
    onSaveCloudApiKey: (String) -> Boolean,
    onClearCloudApiKey: () -> Unit,
    onImportProject: () -> Unit,
    onExportProject: () -> Unit
) {
    var selected by remember { mutableStateOf(StudioTab.CHAT) }
    val colors = project.character.theme
    val voiceOptions by speech.availableVoices.collectAsState()
    val usingCloud = project.inferenceMode == InferenceMode.CLOUD
    val activeEngine = if (usingCloud) cloudEngine else localEngine

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(colors.primaryArgb),
            secondary = Color(colors.secondaryArgb),
            background = Color(colors.backgroundArgb),
            surface = Color(colors.surfaceArgb),
            onPrimary = Color(0xFF08232C),
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Color(colors.backgroundArgb))
                .statusBarsPadding()
                .padding(top = 6.dp)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selected.ordinal,
                edgePadding = 8.dp,
                containerColor = Color(colors.surfaceArgb)
            ) {
                StudioTab.entries.forEach { tab ->
                    Tab(
                        selected = selected == tab,
                        onClick = { selected = tab },
                        text = { Text(tab.label) }
                    )
                }
            }
            Box(Modifier.fillMaxSize()) {
                when (selected) {
                    StudioTab.CHAT -> ChatApp(
                        engine = activeEngine,
                        store = store,
                        speech = speech,
                        speaking = speaking,
                        onChooseModel = { if (usingCloud) selected = StudioTab.MODEL else onChooseModel() },
                        engineLabel = if (usingCloud) "CLOUD" else "LOCAL",
                        engineActionLabel = if (usingCloud) "クラウド" else "GGUF",
                        generationEnabled = !usingCloud || cloudApiKeyConfigured,
                        character = project.character,
                        avatarDesign = project.avatarDesign,
                        motionSettings = project.motion,
                        generationSettings = project.generation
                    )
                    StudioTab.CHARACTER -> CharacterEditor(
                        project = project,
                        onChange = onProjectChange,
                        onTestVoice = {
                            speech.configure(project.character.voice)
                            speech.speak("こんにちは。これが今の声です。これから、もっとあなた好みにしてね。")
                        },
                        voiceOptions = voiceOptions,
                        onImportProject = onImportProject,
                        onExportProject = onExportProject
                    )
                    StudioTab.MODEL -> ModelManager(
                        localEngine = localEngine,
                        cloudEngine = cloudEngine,
                        project = project,
                        modelImporting = modelImporting,
                        cloudApiKeyConfigured = cloudApiKeyConfigured,
                        onChange = onProjectChange,
                        onChooseModel = onChooseModel,
                        onSaveCloudApiKey = onSaveCloudApiKey,
                        onClearCloudApiKey = onClearCloudApiKey
                    )
                    StudioTab.MOTION -> MotionEditor(project = project, onChange = onProjectChange)
                }
            }
        }
    }
}

@Composable
private fun CharacterEditor(
    project: StudioProject,
    onChange: (StudioProject) -> Unit,
    onTestVoice: () -> Unit,
    voiceOptions: List<VoiceOption>,
    onImportProject: () -> Unit,
    onExportProject: () -> Unit
) {
    val character = project.character
    val persona = character.persona
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth().height(300.dp),
                shape = RoundedCornerShape(24.dp)
            ) {
                AvatarSurface(
                    AvatarRenderState(
                        emotion = Emotion.HAPPY,
                        motion = "idle",
                        profile = character.avatar,
                        design = project.avatarDesign,
                        animation = project.motion
                    ),
                    Modifier.fillMaxSize()
                )
            }
        }
        item { SectionTitle("プロフィール") }
        item {
            OutlinedTextField(
                value = persona.name,
                onValueChange = { name ->
                    onChange(project.copy(character = character.copy(persona = persona.copy(name = name.take(24)))))
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("名前") },
                singleLine = true
            )
        }
        item {
            LabeledSlider(
                label = "年齢（成人のみ）",
                valueText = "${persona.age}歳",
                value = persona.age.toFloat(),
                range = 18f..60f,
                steps = 41,
                onValueChange = { age ->
                    onChange(project.copy(character = character.copy(persona = persona.copy(age = age.roundToInt()))))
                }
            )
        }
        item {
            OutlinedTextField(
                value = persona.relationship,
                onValueChange = { value ->
                    onChange(project.copy(character = character.copy(persona = persona.copy(relationship = value))))
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("関係性") },
                minLines = 2
            )
        }
        item {
            OutlinedTextField(
                value = persona.tone,
                onValueChange = { value ->
                    onChange(project.copy(character = character.copy(persona = persona.copy(tone = value))))
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("性格・話し方") },
                minLines = 2
            )
        }
        item {
            OutlinedTextField(
                value = persona.customSystemPrompt,
                onValueChange = { value ->
                    onChange(
                        project.copy(
                            character = character.copy(
                                persona = persona.copy(customSystemPrompt = value.take(8_000))
                            )
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("System Prompt") },
                supportingText = { Text("空欄なら名前・関係性・話し方から標準プロンプトを自動生成します") },
                minLines = 6
            )
        }
        item { SectionTitle("見た目") }
        item {
            Text(
                "現在は確定版メルの立ち絵を表示します。下の設定はキャラクターデータとして保存され、差し替え対応で使われます。",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
        item {
            ChoiceRow(
                label = "髪型",
                options = HairPreset.entries,
                selected = project.avatarDesign.hairPreset,
                optionLabel = { it.label },
                onSelect = { onChange(project.copy(avatarDesign = project.avatarDesign.copy(hairPreset = it))) }
            )
        }
        item {
            ColorChoiceRow(
                label = "髪色",
                selected = project.avatarDesign.hairColorArgb,
                colors = listOf(0xFFF1FBFF, 0xFFFFEADF, 0xFFB8C9F5, 0xFF252B44),
                onSelect = { onChange(project.copy(avatarDesign = project.avatarDesign.copy(hairColorArgb = it))) }
            )
        }
        item {
            ColorChoiceRow(
                label = "アクセント",
                selected = project.avatarDesign.hairAccentArgb,
                colors = listOf(0xFF73D5E8, 0xFFA991F4, 0xFFFF83B3, 0xFF65E0B4),
                onSelect = { onChange(project.copy(avatarDesign = project.avatarDesign.copy(hairAccentArgb = it))) }
            )
        }
        item {
            ColorChoiceRow(
                label = "瞳",
                selected = project.avatarDesign.eyeColorArgb,
                colors = listOf(0xFF47BBD7, 0xFF8C75E8, 0xFFF2B544, 0xFF55C990),
                onSelect = { onChange(project.copy(avatarDesign = project.avatarDesign.copy(eyeColorArgb = it))) }
            )
        }
        item {
            ChoiceRow(
                label = "衣装",
                options = OutfitPreset.entries,
                selected = project.avatarDesign.outfitPreset,
                optionLabel = { it.label },
                onSelect = { onChange(project.copy(avatarDesign = project.avatarDesign.copy(outfitPreset = it))) }
            )
        }
        item { SectionTitle("声") }
        item {
            VoicePresetRow(
                rate = character.voice.speechRate,
                pitch = character.voice.pitch,
                onSelect = { preset ->
                    onChange(
                        project.copy(
                            character = character.copy(
                                voice = character.voice.copy(
                                    speechRate = preset.rate,
                                    pitch = preset.pitch
                                )
                            )
                        )
                    )
                }
            )
        }
        if (voiceOptions.isNotEmpty()) {
            item {
                val selectedVoice = voiceOptions.firstOrNull {
                    it.id == character.voice.preferredVoiceId
                } ?: voiceOptions.first()
                ChoiceRow(
                    label = "端末の日本語音声",
                    options = voiceOptions,
                    selected = selectedVoice,
                    optionLabel = { it.label },
                    onSelect = { option ->
                        onChange(
                            project.copy(
                                character = character.copy(
                                    voice = character.voice.copy(preferredVoiceId = option.id)
                                )
                            )
                        )
                    }
                )
            }
        }
        item {
            LabeledSlider(
                "話す速さ",
                String.format("%.2f", character.voice.speechRate),
                character.voice.speechRate,
                0.5f..1.5f,
                onValueChange = {
                    onChange(project.copy(character = character.copy(voice = character.voice.copy(speechRate = it))))
                }
            )
        }
        item {
            LabeledSlider(
                "声の高さ",
                String.format("%.2f", character.voice.pitch),
                character.voice.pitch,
                0.5f..1.5f,
                onValueChange = {
                    onChange(project.copy(character = character.copy(voice = character.voice.copy(pitch = it))))
                }
            )
        }
        item {
            Button(onClick = onTestVoice, modifier = Modifier.fillMaxWidth()) { Text("この声を試す") }
        }
        item { SectionTitle("キャラクターファイル") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onImportProject, modifier = Modifier.weight(1f)) { Text("読込") }
                Button(onClick = onExportProject, modifier = Modifier.weight(1f)) { Text(".mavatar保存") }
            }
        }
        item { Text("変更は自動保存され、会話画面へすぐ反映されます。", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.64f)) }
    }
}

@Composable
private fun ModelManager(
    localEngine: ConversationEngine,
    cloudEngine: ConversationEngine,
    project: StudioProject,
    modelImporting: Boolean,
    cloudApiKeyConfigured: Boolean,
    onChange: (StudioProject) -> Unit,
    onChooseModel: () -> Unit,
    onSaveCloudApiKey: (String) -> Boolean,
    onClearCloudApiKey: () -> Unit
) {
    val localStatus by localEngine.status.collectAsState()
    val cloudStatus by cloudEngine.status.collectAsState()
    var apiKeyDraft by remember { mutableStateOf("") }
    val usingCloud = project.inferenceMode == InferenceMode.CLOUD
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { SectionTitle("推論モード") }
        item {
            ChoiceRow(
                label = "返答を生成する場所",
                options = InferenceMode.entries,
                selected = project.inferenceMode,
                optionLabel = { it.label },
                onSelect = { onChange(project.copy(inferenceMode = it)) }
            )
        }
        item {
            Text(
                if (usingCloud) {
                    "クラウドAIは高速ですが、会話内容とSystem Promptを外部サービスへ送信します。"
                } else {
                    "端末内GGUFは会話内容を外部へ送信せず、オフラインで動作します。"
                },
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }

        if (!usingCloud) {
            item { SectionTitle("ローカルLLM") }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("現在の状態", style = MaterialTheme.typography.labelMedium)
                        Text(
                            if (modelImporting) {
                                "GGUFをアプリ内へコピー中…"
                            } else when (val current = localStatus) {
                                EngineStatus.Demo -> "デモ会話（GGUF未選択）"
                                is EngineStatus.Loading -> "読込中: ${current.modelName}"
                                is EngineStatus.Ready -> "使用中: ${current.modelName}"
                                is EngineStatus.Error -> "エラー: ${current.message}"
                            }
                        )
                    }
                }
            }
            item {
                Button(
                    onClick = onChooseModel,
                    enabled = !modelImporting,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (modelImporting) "コピー中…" else "端末からGGUFを選ぶ")
                }
            }
            item {
                Text(
                    "選択したモデルをアプリ内へコピーして読み込みます。空き容量はGGUF本体＋約256MB必要です。速度重視なら日本語対応の1.5〜3B・Q4系、品質重視なら3〜4B・Q4系がおすすめです。",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        } else {
            item { SectionTitle("NinjaChat クラウドAI") }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("現在の状態", style = MaterialTheme.typography.labelMedium)
                        Text(
                            when (val current = cloudStatus) {
                                EngineStatus.Demo -> "APIキー未設定"
                                is EngineStatus.Loading -> "接続中: ${current.modelName}"
                                is EngineStatus.Ready -> "使用中: ${current.modelName}"
                                is EngineStatus.Error -> "設定: ${current.message}"
                            }
                        )
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = apiKeyDraft,
                    onValueChange = { apiKeyDraft = it.take(256) },
                    label = { Text("NinjaChat APIキー") },
                    placeholder = { Text(if (cloudApiKeyConfigured) "保存済み（変更する場合だけ入力）" else "nj_sk_...") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            if (onSaveCloudApiKey(apiKeyDraft)) apiKeyDraft = ""
                        },
                        enabled = apiKeyDraft.trim().startsWith("nj_sk_") && apiKeyDraft.trim().length > 12,
                        modifier = Modifier.weight(1f)
                    ) { Text("暗号化して保存") }
                    if (cloudApiKeyConfigured) {
                        OutlinedButton(onClick = onClearCloudApiKey, modifier = Modifier.weight(1f)) {
                            Text("キーを削除")
                        }
                    }
                }
            }
            item {
                Text(
                    "使用モデル: uncensored-ai。APIキーはAndroid Keystoreで暗号化し、この端末だけに保存します。キャラクターファイルやGitHubには含めません。",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
        item { SectionTitle("生成設定") }
        item {
            LabeledSlider(
                "返答の最大長",
                "${project.generation.maxTokens} tokens",
                project.generation.maxTokens.toFloat(),
                64f..384f,
                steps = 9,
                onValueChange = {
                    onChange(project.copy(generation = project.generation.copy(maxTokens = it.roundToInt())))
                }
            )
        }
        item {
            LabeledSlider(
                "発想の自由度",
                String.format("%.2f", project.generation.temperature),
                project.generation.temperature,
                0.1f..1.5f,
                onValueChange = {
                    onChange(project.copy(generation = project.generation.copy(temperature = it)))
                }
            )
        }
        item {
            Text(
                if (usingCloud) {
                    "返答を長くするとクラウドの出力トークン料金も増えます。160 tokens前後が速度・会話量・費用のバランス型です。"
                } else {
                    "160 tokens前後が速度と会話量のバランス型です。さらに速くする場合は短くし、端末メモリが足りない場合は小さいGGUFを選んでください。"
                },
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
private fun MotionEditor(project: StudioProject, onChange: (StudioProject) -> Unit) {
    var emotion by remember { mutableStateOf(Emotion.HAPPY) }
    var talking by remember { mutableStateOf(false) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth().height(320.dp), shape = RoundedCornerShape(24.dp)) {
                AvatarSurface(
                    AvatarRenderState(
                        emotion = emotion,
                        motion = "preview",
                        speaking = talking,
                        profile = project.character.avatar,
                        design = project.avatarDesign,
                        animation = project.motion
                    ),
                    Modifier.fillMaxSize()
                )
            }
        }
        item {
            ChoiceRow(
                label = "表情プレビュー",
                options = Emotion.entries,
                selected = emotion,
                optionLabel = { it.name },
                onSelect = { emotion = it }
            )
        }
        item {
            OutlinedButton(onClick = { talking = !talking }, modifier = Modifier.fillMaxWidth()) {
                Text(if (talking) "口パクを止める" else "口パクを試す")
            }
        }
        item { SectionTitle("アニメーション") }
        item {
            LabeledSlider("呼吸", percent(project.motion.breathStrength), project.motion.breathStrength, 0f..1f) {
                onChange(project.copy(motion = project.motion.copy(breathStrength = it)))
            }
        }
        item {
            LabeledSlider("体の揺れ", percent(project.motion.swayStrength), project.motion.swayStrength, 0f..1f) {
                onChange(project.copy(motion = project.motion.copy(swayStrength = it)))
            }
        }
        item {
            LabeledSlider("まばたき頻度", percent(project.motion.blinkSpeed), project.motion.blinkSpeed, 0f..1f) {
                onChange(project.copy(motion = project.motion.copy(blinkSpeed = it)))
            }
        }
        item {
            LabeledSlider("口の開き", percent(project.motion.mouthStrength), project.motion.mouthStrength, 0f..1f) {
                onChange(project.copy(motion = project.motion.copy(mouthStrength = it)))
            }
        }
        item { Text("変更は自動保存され、音声再生と会話中の動きに反映されます。", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.64f)) }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun VoicePresetRow(
    rate: Float,
    pitch: Float,
    onSelect: (VoicePreset) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("声プリセット")
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            voicePresets.forEach { preset ->
                FilterChip(
                    selected = kotlin.math.abs(rate - preset.rate) < 0.02f &&
                        kotlin.math.abs(pitch - preset.pitch) < 0.02f,
                    onClick = { onSelect(preset) },
                    label = { Text(preset.label) }
                )
            }
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(valueText, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value, onValueChange = onValueChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun <T> ChoiceRow(
    label: String,
    options: List<T>,
    selected: T,
    optionLabel: (T) -> String,
    onSelect: (T) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { option ->
                FilterChip(
                    selected = option == selected,
                    onClick = { onSelect(option) },
                    label = { Text(optionLabel(option)) }
                )
            }
        }
    }
}

@Composable
private fun ColorChoiceRow(
    label: String,
    selected: Long,
    colors: List<Long>,
    onSelect: (Long) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            colors.forEach { color ->
                FilterChip(
                    selected = color == selected,
                    onClick = { onSelect(color) },
                    label = {
                        Box(
                            Modifier.size(22.dp).background(Color(color), CircleShape)
                        )
                    }
                )
            }
        }
    }
}

private fun percent(value: Float): String = "${(value * 100).roundToInt()}%"
