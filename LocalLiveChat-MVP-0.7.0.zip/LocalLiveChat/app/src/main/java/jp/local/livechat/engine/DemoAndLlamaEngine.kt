package jp.local.livechat.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import jp.local.livechat.model.CharacterResponse
import jp.local.livechat.model.ChatMessage
import jp.local.livechat.model.Emotion
import jp.local.livechat.model.GenerationSettings
import jp.local.livechat.model.Persona

class DemoAndLlamaEngine : ConversationEngine {
    private val dispatcher = Dispatchers.IO.limitedParallelism(1)
    private val _status = MutableStateFlow<EngineStatus>(EngineStatus.Demo)
    override val status = _status.asStateFlow()

    override suspend fun loadModel(path: String, modelName: String): Result<Unit> = withContext(dispatcher) {
        _status.value = EngineStatus.Loading(modelName)
        runCatching {
            check(LlamaCppBridge.loadModel(path)) {
                LlamaCppBridge.lastError().ifBlank { "GGUFを読み込めませんでした" }
            }
            _status.value = EngineStatus.Ready(modelName)
        }.onFailure {
            _status.value = EngineStatus.Error(it.message ?: "モデル読込エラー")
        }
    }

    override suspend fun reply(
        history: List<ChatMessage>,
        persona: Persona,
        settings: GenerationSettings,
        onToken: suspend (String) -> Unit
    ): CharacterResponse = withContext(dispatcher) {
        if (_status.value !is EngineStatus.Ready) {
            return@withContext demoReply(history.lastOrNull()?.text.orEmpty(), onToken)
        }

        val conversation = buildString {
            history.takeLast(8).forEach {
                append(if (it.speaker.name == "USER") "ユーザー: " else "${persona.name}: ")
                appendLine(it.text)
            }
        }
        val safeSettings = settings.normalized()
        val streamingSpeech = StreamingSpeechExtractor()
        var emittedSpeech = false
        val raw = LlamaCppBridge.generateStreaming(
            persona.systemPrompt(),
            conversation,
            safeSettings.maxTokens,
            safeSettings.temperature,
            TokenCallback { rawToken ->
                val delta = streamingSpeech.accept(rawToken)
                if (delta.isNotEmpty()) {
                    emittedSpeech = true
                    runBlocking { onToken(delta) }
                }
            }
        )
        if (raw.isBlank()) {
            val message = LlamaCppBridge.lastError()
            if (message.isBlank()) {
                return@withContext CharacterResponse(
                    speech = "……うん。ここで止めておきますね。",
                    emotion = Emotion.NEUTRAL,
                    motion = "idle"
                )
            }
            _status.value = EngineStatus.Error(message)
            return@withContext CharacterResponse(
                speech = "ごめんなさい、いま上手く考えられなかったみたい。モデル設定を確認してね。",
                emotion = Emotion.SAD,
                motion = "troubled"
            )
        }
        val parsed = StructuredResponseParser.parse(raw)
        val response = streamingSpeech.value().takeIf { it.isNotEmpty() }
            ?.let { parsed.copy(speech = it) }
            ?: parsed
        if (!emittedSpeech && response.speech.isNotEmpty()) onToken(response.speech)
        response
    }

    private suspend fun demoReply(
        input: String,
        onToken: suspend (String) -> Unit
    ): CharacterResponse {
        delay(420)
        val response = when {
            listOf("好き", "かわいい", "愛して").any(input::contains) -> CharacterResponse(
                "えへへ……そんなこと言われたら、もっとご主人さまのそばにいたくなっちゃいます。",
                Emotion.SHY,
                "look_away",
                2
            )
            listOf("疲れ", "しんど", "眠い").any(input::contains) -> CharacterResponse(
                "今日はよく頑張りましたね。ここでは力を抜いて、メルに甘えてください。",
                Emotion.LOVING,
                "lean_in",
                1
            )
            else -> CharacterResponse(
                "はい、ご主人さま。もっと聞かせてください。メル、ちゃんと覚えていたいです。",
                Emotion.HAPPY,
                "nod",
                1
            )
        }
        response.speech.chunked(2).forEach { chunk ->
            onToken(chunk)
            delay(18)
        }
        return response
    }

    override fun close() {
        LlamaCppBridge.cancel()
        LlamaCppBridge.unload()
        _status.value = EngineStatus.Demo
    }

    override fun cancelGeneration() = LlamaCppBridge.cancel()
}

private fun interface TokenCallback {
    fun onToken(token: String)
}

private object LlamaCppBridge {
    init {
        System.loadLibrary("local_llm")
    }

    external fun loadModel(path: String): Boolean
    external fun generateStreaming(
        systemPrompt: String,
        conversation: String,
        maxTokens: Int,
        temperature: Float,
        callback: TokenCallback
    ): String
    external fun cancel()
    external fun unload()
    external fun lastError(): String
}

internal class StreamingSpeechExtractor {
    private val raw = StringBuilder()
    private var emittedCharacters = 0
    private var currentSpeech = ""

    fun accept(token: String): String {
        raw.append(token)
        val text = raw.toString()
        val marker = SPEECH_MARKER.find(text) ?: return ""
        var index = marker.range.last + 1
        val decoded = StringBuilder()
        while (index < text.length) {
            val value = text[index++]
            if (value == '"') break
            if (value != '\\') {
                decoded.append(value)
                continue
            }
            if (index >= text.length) break
            when (val escaped = text[index++]) {
                '"', '\\', '/' -> decoded.append(escaped)
                'b' -> decoded.append('\b')
                'f' -> decoded.append('\u000C')
                'n' -> decoded.append('\n')
                'r' -> decoded.append('\r')
                't' -> decoded.append('\t')
                'u' -> {
                    if (index + 4 > text.length) break
                    val code = text.substring(index, index + 4).toIntOrNull(16) ?: break
                    decoded.append(code.toChar())
                    index += 4
                }
            }
        }
        currentSpeech = decoded.toString()
        if (decoded.length <= emittedCharacters) return ""
        return decoded.substring(emittedCharacters).also { emittedCharacters = decoded.length }
    }

    fun value(): String = currentSpeech

    private companion object {
        val SPEECH_MARKER = Regex("\\\"speech\\\"\\s*:\\s*\\\"")
    }
}
