package jp.local.livechat.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import jp.local.livechat.model.CharacterResponse
import jp.local.livechat.model.ChatMessage
import jp.local.livechat.model.Emotion
import jp.local.livechat.model.GenerationSettings
import jp.local.livechat.model.Persona
import jp.local.livechat.model.Speaker
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

class NinjaChatEngine : ConversationEngine {
    private val dispatcher = Dispatchers.IO.limitedParallelism(1)
    private val _status = MutableStateFlow<EngineStatus>(EngineStatus.Error("NinjaChat APIキー未設定"))
    override val status = _status.asStateFlow()

    @Volatile
    private var apiKey = ""

    @Volatile
    private var activeConnection: HttpURLConnection? = null

    private val cancelRequested = AtomicBoolean(false)

    fun configureApiKey(value: String) {
        apiKey = value.trim()
        _status.value = if (apiKey.isBlank()) {
            EngineStatus.Error("NinjaChat APIキー未設定")
        } else {
            EngineStatus.Ready("NinjaChat / $MODEL_ID")
        }
    }

    override suspend fun loadModel(path: String, modelName: String): Result<Unit> =
        Result.failure(UnsupportedOperationException("クラウドモードではGGUFを読み込みません"))

    override suspend fun reply(
        history: List<ChatMessage>,
        persona: Persona,
        settings: GenerationSettings,
        onToken: suspend (String) -> Unit
    ): CharacterResponse = withContext(dispatcher) {
        val requestKey = apiKey
        if (requestKey.isBlank()) {
            return@withContext CharacterResponse(
                speech = "モデル画面でNinjaChat APIキーを設定してください。",
                emotion = Emotion.SAD,
                motion = "troubled"
            )
        }

        cancelRequested.set(false)
        val rawResponse = StringBuilder()
        val streamingSpeech = StreamingSpeechExtractor()
        var connection: HttpURLConnection? = null
        try {
            val requestConnection = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 180_000
                doOutput = true
                setRequestProperty("Authorization", "Bearer $requestKey")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "text/event-stream")
            }
            connection = requestConnection
            activeConnection = requestConnection
            val body = createRequest(history, persona, settings.normalized()).toString()
                .toByteArray(Charsets.UTF_8)
            requestConnection.setFixedLengthStreamingMode(body.size)
            requestConnection.outputStream.use { it.write(body) }

            val statusCode = requestConnection.responseCode
            if (statusCode !in 200..299) {
                val details = requestConnection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                val message = providerError(statusCode, details)
                _status.value = EngineStatus.Error(message)
                return@withContext CharacterResponse(message, Emotion.SAD, "troubled")
            }

            requestConnection.inputStream.bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    if (cancelRequested.get()) break
                    if (!line.startsWith("data:")) continue
                    val data = line.removePrefix("data:").trim()
                    if (data == "[DONE]") break
                    val token = runCatching {
                        JSONObject(data)
                            .optJSONArray("choices")
                            ?.optJSONObject(0)
                            ?.optJSONObject("delta")
                            ?.optString("content")
                            .orEmpty()
                    }.getOrDefault("")
                    if (token.isEmpty()) continue
                    rawResponse.append(token)
                    val speechDelta = streamingSpeech.accept(token)
                    if (speechDelta.isNotEmpty()) onToken(speechDelta)
                }
            }

            val parsed = StructuredResponseParser.parse(rawResponse.toString())
            val finalSpeech = streamingSpeech.value().ifEmpty { parsed.speech }
            if (streamingSpeech.value().isEmpty() && finalSpeech.isNotEmpty()) onToken(finalSpeech)
            _status.value = EngineStatus.Ready("NinjaChat / $MODEL_ID")
            parsed.copy(speech = finalSpeech.ifBlank { "生成を停止しました。" })
        } catch (error: IOException) {
            if (cancelRequested.get()) {
                val partial = streamingSpeech.value()
                CharacterResponse(
                    speech = partial.ifBlank { "生成を停止しました。" },
                    emotion = Emotion.NEUTRAL,
                    motion = "idle"
                )
            } else {
                val message = "クラウドAIへ接続できませんでした。通信状態を確認してください。"
                _status.value = EngineStatus.Error(message)
                CharacterResponse(message, Emotion.SAD, "troubled")
            }
        } finally {
            activeConnection = null
            connection?.disconnect()
        }
    }

    override fun cancelGeneration() {
        cancelRequested.set(true)
        activeConnection?.disconnect()
    }

    override fun close() = cancelGeneration()

    private fun createRequest(
        history: List<ChatMessage>,
        persona: Persona,
        settings: GenerationSettings
    ): JSONObject {
        val messages = JSONArray().put(
            JSONObject()
                .put("role", "system")
                .put("content", persona.systemPrompt())
        )
        history.takeLast(30).forEach { message ->
            messages.put(
                JSONObject()
                    .put("role", if (message.speaker == Speaker.USER) "user" else "assistant")
                    .put("content", message.text)
            )
        }
        return JSONObject()
            .put("model", MODEL_ID)
            .put("messages", messages)
            .put("temperature", settings.temperature.toDouble())
            .put("max_tokens", settings.maxTokens)
            .put("stream", true)
    }

    private fun providerError(statusCode: Int, raw: String): String {
        val providerMessage = runCatching {
            val error = JSONObject(raw).opt("error")
            when (error) {
                is JSONObject -> error.optString("message")
                is String -> error
                else -> JSONObject(raw).optString("message")
            }
        }.getOrDefault("")
        return when (statusCode) {
            401, 403 -> "NinjaChat APIキーが無効です。"
            402 -> "NinjaChatのクレジット残高が不足しています。"
            429 -> "NinjaChatの利用上限に達しました。少し待って再試行してください。"
            else -> providerMessage.takeIf { it.isNotBlank() }
                ?.let { "NinjaChatエラー: ${it.take(180)}" }
                ?: "NinjaChatエラー（HTTP $statusCode）"
        }
    }

    private companion object {
        const val MODEL_ID = "uncensored-ai"
        const val ENDPOINT = "https://www.ninjachat.ai/api/v1/chat/completions"
    }
}
