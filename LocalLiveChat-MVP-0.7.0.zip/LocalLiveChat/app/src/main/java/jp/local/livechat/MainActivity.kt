package jp.local.livechat

import android.os.Bundle
import android.os.StatFs
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import jp.local.livechat.data.ConversationStore
import jp.local.livechat.data.SecureApiKeyStore
import jp.local.livechat.data.StudioStore
import jp.local.livechat.engine.DemoAndLlamaEngine
import jp.local.livechat.engine.NinjaChatEngine
import jp.local.livechat.speech.SpeechController
import jp.local.livechat.ui.StudioApp
import java.io.File

class MainActivity : ComponentActivity() {
    private val localEngine = DemoAndLlamaEngine()
    private val cloudEngine = NinjaChatEngine()
    private lateinit var speech: SpeechController
    private lateinit var secureApiKeyStore: SecureApiKeyStore
    private var speaking by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speech = SpeechController(this) { value -> runOnUiThread { speaking = value } }
        val store = ConversationStore(this)
        val studioStore = StudioStore(this)
        secureApiKeyStore = SecureApiKeyStore(this)
        val storedCloudApiKey = secureApiKeyStore.load().orEmpty()
        cloudEngine.configureApiKey(storedCloudApiKey)

        setContent {
            val isSpeaking = speaking
            var project by remember { mutableStateOf(studioStore.load()) }
            var modelImporting by remember { mutableStateOf(false) }
            var cloudApiKeyConfigured by remember { mutableStateOf(storedCloudApiKey.isNotBlank()) }
            val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri == null) return@rememberLauncherForActivityResult
                lifecycleScope.launch {
                    modelImporting = true
                    Toast.makeText(
                        this@MainActivity,
                        "GGUFをアプリ内へコピーしています。しばらくお待ちください",
                        Toast.LENGTH_LONG
                    ).show()
                    val result = withContext(Dispatchers.IO) { runCatching {
                        val metadata = contentResolver.query(
                            uri,
                            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                            null,
                            null,
                            null
                        )?.use { cursor ->
                            if (!cursor.moveToFirst()) null else {
                                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                                val name = if (nameIndex >= 0) cursor.getString(nameIndex) else null
                                val size = if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) cursor.getLong(sizeIndex) else -1L
                                name to size
                            }
                        }
                        val modelName = metadata?.first ?: "local-model.gguf"
                        require(modelName.endsWith(".gguf", ignoreCase = true)) {
                            "GGUF形式のファイルを選んでください"
                        }

                        val declaredSize = metadata?.second ?: -1L
                        val available = StatFs(filesDir.absolutePath).availableBytes
                        if (declaredSize > 0) {
                            require(available > declaredSize + 256L * 1024 * 1024) {
                                "空き容量が不足しています（モデル本体に加えて約256MB必要です）"
                            }
                        }

                        val modelDirectory = File(filesDir, "models").apply { mkdirs() }
                        val pending = File(modelDirectory, "import-${System.currentTimeMillis()}.part")
                        val installed = File(modelDirectory, "model-${System.currentTimeMillis()}.gguf")
                        try {
                            val source = requireNotNull(contentResolver.openInputStream(uri)) {
                                "選択したファイルを開けません"
                            }
                            source.buffered().use { input ->
                                pending.outputStream().buffered().use { output ->
                                    input.copyTo(output, bufferSize = 8 * 1024 * 1024)
                                }
                            }
                            require(pending.length() > 0L) { "選択したファイルが空です" }
                            if (declaredSize > 0) {
                                require(pending.length() == declaredSize) { "モデルのコピーが途中で失敗しました" }
                            }
                            require(pending.renameTo(installed)) { "モデルをアプリ内へ保存できません" }
                            localEngine.loadModel(installed.absolutePath, modelName).getOrThrow()
                            modelDirectory.listFiles()?.forEach { oldFile ->
                                if (oldFile != installed) oldFile.delete()
                            }
                        } catch (error: Throwable) {
                            pending.delete()
                            installed.delete()
                            throw error
                        }
                    } }
                    modelImporting = false
                    Toast.makeText(
                        this@MainActivity,
                        result.fold({ "GGUFを読み込みました" }, { "読込失敗: ${it.message}" }),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            val avatarImportPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri == null) return@rememberLauncherForActivityResult
                val result = runCatching {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    requireNotNull(raw) { "ファイルを開けません" }
                    studioStore.import(raw)
                }
                result.onSuccess { imported ->
                    project = imported
                    studioStore.save(imported)
                }
                Toast.makeText(
                    this@MainActivity,
                    result.fold({ "キャラクターを読み込みました" }, { "読込失敗: ${it.message}" }),
                    Toast.LENGTH_LONG
                ).show()
            }
            val avatarExportPicker = rememberLauncherForActivityResult(
                ActivityResultContracts.CreateDocument("application/json")
            ) { uri ->
                if (uri == null) return@rememberLauncherForActivityResult
                val result = runCatching {
                    contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                        it.write(studioStore.export(project))
                    } ?: error("保存先を開けません")
                }
                Toast.makeText(
                    this@MainActivity,
                    result.fold({ "キャラクターを保存しました" }, { "保存失敗: ${it.message}" }),
                    Toast.LENGTH_LONG
                ).show()
            }

            StudioApp(
                localEngine = localEngine,
                cloudEngine = cloudEngine,
                store = store,
                speech = speech,
                speaking = isSpeaking,
                project = project,
                modelImporting = modelImporting,
                cloudApiKeyConfigured = cloudApiKeyConfigured,
                onProjectChange = { updated ->
                    project = updated.normalized()
                    studioStore.save(project)
                },
                onChooseModel = { modelPicker.launch(arrayOf("application/octet-stream", "*/*")) },
                onSaveCloudApiKey = { value ->
                    val result = runCatching {
                        secureApiKeyStore.save(value)
                        cloudEngine.configureApiKey(value)
                    }
                    result.onSuccess { cloudApiKeyConfigured = true }
                    Toast.makeText(
                        this@MainActivity,
                        result.fold({ "NinjaChat APIキーを暗号化して保存しました" }, { "保存失敗: ${it.message}" }),
                        Toast.LENGTH_LONG
                    ).show()
                    result.isSuccess
                },
                onClearCloudApiKey = {
                    secureApiKeyStore.clear()
                    cloudEngine.configureApiKey("")
                    cloudApiKeyConfigured = false
                    Toast.makeText(this@MainActivity, "NinjaChat APIキーを削除しました", Toast.LENGTH_LONG).show()
                },
                onImportProject = { avatarImportPicker.launch(arrayOf("application/json", "*/*")) },
                onExportProject = {
                    val safeName = project.character.persona.name.ifBlank { "character" }
                        .replace(Regex("[^A-Za-z0-9ぁ-んァ-ヶ一-龠_-]"), "_")
                    avatarExportPicker.launch("$safeName.mavatar")
                }
            )
        }
    }

    override fun onDestroy() {
        localEngine.close()
        cloudEngine.close()
        speech.shutdown()
        super.onDestroy()
    }
}
