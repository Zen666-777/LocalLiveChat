package jp.local.livechat.engine

import jp.local.livechat.model.CharacterResponse
import jp.local.livechat.model.ChatMessage
import jp.local.livechat.model.Emotion
import jp.local.livechat.model.GenerationSettings
import jp.local.livechat.model.Persona
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject

sealed interface EngineStatus {
    data object Demo : EngineStatus
    data class Loading(val modelName: String) : EngineStatus
    data class Ready(val modelName: String) : EngineStatus
    data class Error(val message: String) : EngineStatus
}

interface ConversationEngine {
    val status: StateFlow<EngineStatus>
    suspend fun loadModel(path: String, modelName: String): Result<Unit>
    suspend fun reply(
        history: List<ChatMessage>,
        persona: Persona,
        settings: GenerationSettings = GenerationSettings(),
        onToken: suspend (String) -> Unit = {}
    ): CharacterResponse
    fun cancelGeneration()
    fun close()
}

object StructuredResponseParser {
    fun parse(raw: String): CharacterResponse {
        val jsonText = raw.substringAfter('{', missingDelimiterValue = "")
            .substringBeforeLast('}', missingDelimiterValue = "")
            .takeIf { it.isNotBlank() }
            ?.let { "{$it}" }
            ?: return CharacterResponse(raw.trim().ifBlank { "……うまく言葉にできなかったみたい。" })

        return runCatching {
            val json = JSONObject(jsonText)
            CharacterResponse(
                speech = json.optString("speech").ifBlank { raw.trim() },
                emotion = runCatching {
                    Emotion.valueOf(json.optString("emotion", "NEUTRAL").uppercase())
                }.getOrDefault(Emotion.NEUTRAL),
                motion = json.optString("motion", "idle"),
                intimacyDelta = json.optInt("intimacy_delta", 0).coerceIn(-5, 5)
            )
        }.getOrElse { CharacterResponse(raw.trim()) }
    }
}
