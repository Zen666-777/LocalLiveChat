package jp.local.livechat.engine

import org.junit.Assert.assertEquals
import org.junit.Test

class StreamingSpeechExtractorTest {
    @Test
    fun emitsOnlyNewSpeechCharactersAcrossTokens() {
        val extractor = StreamingSpeechExtractor()

        assertEquals("", extractor.accept("{\"spe"))
        assertEquals("こん", extractor.accept("ech\":\"こん"))
        assertEquals("にちは", extractor.accept("にちは\",\"emotion\":\"HAPPY\"}"))
        assertEquals("", extractor.accept("ignored"))
    }

    @Test
    fun decodesEscapedNewline() {
        val extractor = StreamingSpeechExtractor()

        assertEquals("一行目\n二行目", extractor.accept("{\"speech\":\"一行目\\n二行目\"}"))
    }
}
