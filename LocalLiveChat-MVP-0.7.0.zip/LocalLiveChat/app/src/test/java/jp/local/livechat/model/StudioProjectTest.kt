package jp.local.livechat.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StudioProjectTest {
    @Test
    fun normalizationKeepsCharacterAdultAndSettingsSafe() {
        val base = BuiltInCharacters.Meru
        val project = StudioProject(
            character = base.copy(
                persona = base.persona.copy(age = 12),
                voice = base.voice.copy(speechRate = 4f, pitch = 0.1f)
            ),
            motion = MotionSettings(breathStrength = -1f, mouthStrength = 2f),
            generation = GenerationSettings(maxTokens = 8, temperature = 9f)
        ).normalized()

        assertEquals(18, project.character.persona.age)
        assertEquals(1.5f, project.character.voice.speechRate, 0.001f)
        assertEquals(0.5f, project.character.voice.pitch, 0.001f)
        assertEquals(0f, project.motion.breathStrength, 0.001f)
        assertEquals(1f, project.motion.mouthStrength, 0.001f)
        assertEquals(64, project.generation.maxTokens)
        assertEquals(1.5f, project.generation.temperature, 0.001f)
    }

    @Test
    fun customSystemPromptStillRequiresStructuredResponse() {
        val prompt = Persona(customSystemPrompt = "あなたはテスト用キャラクターです。").systemPrompt()

        assertTrue(prompt.contains("あなたはテスト用キャラクターです。"))
        assertTrue(prompt.contains("必ず次のJSONだけを出力してください"))
        assertTrue(prompt.contains("intimacy_delta"))
    }
}
