package jp.local.livechat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import jp.local.livechat.avatar.AvatarRenderState
import jp.local.livechat.data.ConversationStore
import jp.local.livechat.engine.ConversationEngine
import jp.local.livechat.engine.EngineStatus
import jp.local.livechat.model.Emotion
import jp.local.livechat.model.HairPreset
import jp.local.livechat.model.OutfitPreset
import jp.local.livechat.model.StudioProject
import jp.local.livechat.speech.SpeechController
import kotlin.math.roundToInt

private enum class StudioTab(val label: String) {
    CHAT("会話"), CHARACTER("キャラ"), MODEL("モデル"), MOTION("動き")
}

@Composable
fun StudioApp(
    engine: ConversationEngine,
    store: ConversationStore,
    speech: SpeechController,
    speaking: Boolean,
    project: StudioProject,
    onProjectChange: (StudioProject) -> Unit,
    onChooseModel: () -> Unit,
    onImportProject: () -> Unit,
    onExportProject: () -> Unit
) {
    var selected by remember { mutableStateOf(StudioTab.CHAT) }
    val colors = project.character.theme

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(colors.primaryArgb),
            secondary = Color(colors.secondaryArgb),
            background = Color(colors.backgroundArgb),
            surface = Color(colors.surfaceArgb),
            onPrimary = Color(0xFF08232C),
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Column(Modifier.fillMaxSize().background(Color(colors.backgroundArgb))) {
            ScrollableTabRow(
                selectedTabIndex = selected.ordinal,
                edgePadding = 8.dp,
                containerColor = Color(colors.surfaceArgb)
            ) {
                StudioTab.entries.forEach { tab ->
                    Tab(
                        selected = selected == tab,
                        onClick = { selected = tab },
                        text = { Text(tab.label) }
                    )
                }
            }
            Box(Modifier.fillMaxSize()) {
                when (selected) {
                    StudioTab.CHAT -> ChatApp(
                        engine = engine,
                        store = store,
                        speech = speech,
                        speaking = speaking,
                        onChooseModel = onChooseModel,
                        character = project.character,
                        avatarDesign = project.avatarDesign,
                        motionSettings = project.motion,
                        generationSettings = project.generation
                    )
                    StudioTab.CHARACTER -> CharacterEditor(
                        project = project,
                        onChange = onProjectChange,
                        onTestVoice = {
                            speech.configure(project.character.voice)
                            speech.speak("こんにちは。これが今の声です。これから、もっとあなた好みにしてね。")
                        },
                        onImportProject = onImportProject,
                        onExportProject = onExportProject
                    )
                    StudioTab.MODEL -> ModelManager(
                        engine = engine,
                        project = project,
                        onChange = onProjectChange,
                        onChooseModel = onChooseModel
                    )
                    StudioTab.MOTION -> MotionEditor(project = project, onChange = onProjectChange)
                }
            }
        }
    }
}

@Composable
private fun CharacterEditor(
    project: StudioProject,
    onChange: (StudioProject) -> Unit,
    onTestVoice: () -> Unit,
    onImportProject: () -> Unit,
    onExportProject: () -> Unit
) {
    val character = project.character
    val persona = character.persona
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth().height(300.dp),
                shape = RoundedCornerShape(24.dp)
            ) {
                AvatarSurface(
                    AvatarRenderState(
                        emotion = Emotion.HAPPY,
                        motion = "idle",
                        profile = character.avatar,
                        design = project.avatarDesign,
                        animation = project.motion
                    ),
                    Modifier.fillMaxSize()
                )
            }
        }
        item { SectionTitle("プロフィール") }
        item {
            OutlinedTextField(
                value = persona.name,
                onValueChange = { name ->
                    onChange(project.copy(character = character.copy(persona = persona.copy(name = name.take(24)))))
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("名前") },
                singleLine = true
            )
        }
        item {
            LabeledSlider(
                label = "年齢（成人のみ）",
                valueText = "${persona.age}歳",
                value = persona.age.toFloat(),
                range = 18f..60f,
                steps = 41,
                onValueChange = { age ->
                    onChange(project.copy(character = character.copy(persona = persona.copy(age = age.roundToInt()))))
                }
            )
        }
        item {
            OutlinedTextField(
                value = persona.relationship,
                onValueChange = { value ->
                    onChange(project.copy(character = character.copy(persona = persona.copy(relationship = value))))
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("関係性") },
                minLines = 2
            )
        }
        item {
            OutlinedTextField(
                value = persona.tone,
                onValueChange = { value ->
                    onChange(project.copy(character = character.copy(persona = persona.copy(tone = value))))
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("性格・話し方") },
                minLines = 2
            )
        }
        item { SectionTitle("見た目") }
        item {
            ChoiceRow(
                label = "髪型",
                options = HairPreset.entries,
                selected = project.avatarDesign.hairPreset,
                optionLabel = { it.label },
                onSelect = { onChange(project.copy(avatarDesign = project.avatarDesign.copy(hairPreset = it))) }
            )
        }
        item {
            ColorChoiceRow(
                label = "髪色",
                selected = project.avatarDesign.hairColorArgb,
                colors = listOf(0xFFF1FBFF, 0xFFFFEADF, 0xFFB8C9F5, 0xFF252B44),
                onSelect = { onChange(project.copy(avatarDesign = project.avatarDesign.copy(hairColorArgb = it))) }
            )
        }
        item {
            ColorChoiceRow(
                label = "アクセント",
                selected = project.avatarDesign.hairAccentArgb,
                colors = listOf(0xFF73D5E8, 0xFFA991F4, 0xFFFF83B3, 0xFF65E0B4),
                onSelect = { onChange(project.copy(avatarDesign = project.avatarDesign.copy(hairAccentArgb = it))) }
            )
        }
        item {
            ColorChoiceRow(
                label = "瞳",
                selected = project.avatarDesign.eyeColorArgb,
                colors = listOf(0xFF47BBD7, 0xFF8C75E8, 0xFFF2B544, 0xFF55C990),
                onSelect = { onChange(project.copy(avatarDesign = project.avatarDesign.copy(eyeColorArgb = it))) }
            )
        }
        item {
            ChoiceRow(
                label = "衣装",
                options = OutfitPreset.entries,
                selected = project.avatarDesign.outfitPreset,
                optionLabel = { it.label },
                onSelect = { onChange(project.copy(avatarDesign = project.avatarDesign.copy(outfitPreset = it))) }
            )
        }
        item { SectionTitle("声") }
        item {
            LabeledSlider(
                "話す速さ",
                String.format("%.2f", character.voice.speechRate),
                character.voice.speechRate,
                0.5f..1.5f,
                onValueChange = {
                    onChange(project.copy(character = character.copy(voice = character.voice.copy(speechRate = it))))
                }
            )
        }
        item {
            LabeledSlider(
                "声の高さ",
                String.format("%.2f", character.voice.pitch),
                character.voice.pitch,
                0.5f..1.5f,
                onValueChange = {
                    onChange(project.copy(character = character.copy(voice = character.voice.copy(pitch = it))))
                }
            )
        }
        item {
            Button(onClick = onTestVoice, modifier = Modifier.fillMaxWidth()) { Text("この声を試す") }
        }
        item { SectionTitle("キャラクターファイル") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onImportProject, modifier = Modifier.weight(1f)) { Text("読込") }
                Button(onClick = onExportProject, modifier = Modifier.weight(1f)) { Text(".mavatar保存") }
            }
        }
        item { Text("変更は自動保存され、会話画面へすぐ反映されます。", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.64f)) }
    }
}

@Composable
private fun ModelManager(
    engine: ConversationEngine,
    project: StudioProject,
    onChange: (StudioProject) -> Unit,
    onChooseModel: () -> Unit
) {
    val status by engine.status.collectAsState()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { SectionTitle("ローカルLLM") }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("現在の状態", style = MaterialTheme.typography.labelMedium)
                    Text(
                        when (val current = status) {
                            EngineStatus.Demo -> "デモ会話（GGUF未選択）"
                            is EngineStatus.Loading -> "読込中: ${current.modelName}"
                            is EngineStatus.Ready -> "使用中: ${current.modelName}"
                            is EngineStatus.Error -> "エラー: ${current.message}"
                        }
                    )
                }
            }
        }
        item { Button(onClick = onChooseModel, modifier = Modifier.fillMaxWidth()) { Text("端末からGGUFを選ぶ") } }
        item {
            Text(
                "モデルは端末内から直接読み込みます。最初は日本語対応の3〜4B・Q4系が扱いやすいです。",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
        item { SectionTitle("生成設定") }
        item {
            LabeledSlider(
                "返答の最大長",
                "${project.generation.maxTokens} tokens",
                project.generation.maxTokens.toFloat(),
                64f..768f,
                steps = 10,
                onValueChange = {
                    onChange(project.copy(generation = project.generation.copy(maxTokens = it.roundToInt())))
                }
            )
        }
        item {
            LabeledSlider(
                "発想の自由度",
                String.format("%.2f", project.generation.temperature),
                project.generation.temperature,
                0.1f..1.5f,
                onValueChange = {
                    onChange(project.copy(generation = project.generation.copy(temperature = it)))
                }
            )
        }
        item {
            Text(
                "0.6前後は安定、0.8〜1.0は会話に変化が出ます。端末メモリが足りない場合は小さいGGUFを選んでください。",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
private fun MotionEditor(project: StudioProject, onChange: (StudioProject) -> Unit) {
    var emotion by remember { mutableStateOf(Emotion.HAPPY) }
    var talking by remember { mutableStateOf(false) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth().height(320.dp), shape = RoundedCornerShape(24.dp)) {
                AvatarSurface(
                    AvatarRenderState(
                        emotion = emotion,
                        motion = "preview",
                        speaking = talking,
                        profile = project.character.avatar,
                        design = project.avatarDesign,
                        animation = project.motion
                    ),
                    Modifier.fillMaxSize()
                )
            }
        }
        item {
            ChoiceRow(
                label = "表情プレビュー",
                options = Emotion.entries,
                selected = emotion,
                optionLabel = { it.name },
                onSelect = { emotion = it }
            )
        }
        item {
            OutlinedButton(onClick = { talking = !talking }, modifier = Modifier.fillMaxWidth()) {
                Text(if (talking) "口パクを止める" else "口パクを試す")
            }
        }
        item { SectionTitle("アニメーション") }
        item {
            LabeledSlider("呼吸", percent(project.motion.breathStrength), project.motion.breathStrength, 0f..1f) {
                onChange(project.copy(motion = project.motion.copy(breathStrength = it)))
            }
        }
        item {
            LabeledSlider("体の揺れ", percent(project.motion.swayStrength), project.motion.swayStrength, 0f..1f) {
                onChange(project.copy(motion = project.motion.copy(swayStrength = it)))
            }
        }
        item {
            LabeledSlider("まばたき頻度", percent(project.motion.blinkSpeed), project.motion.blinkSpeed, 0f..1f) {
                onChange(project.copy(motion = project.motion.copy(blinkSpeed = it)))
            }
        }
        item {
            LabeledSlider("口の開き", percent(project.motion.mouthStrength), project.motion.mouthStrength, 0f..1f) {
                onChange(project.copy(motion = project.motion.copy(mouthStrength = it)))
            }
        }
        item { Text("変更は自動保存され、音声再生と会話中の動きに反映されます。", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.64f)) }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun LabeledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(valueText, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value, onValueChange = onValueChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun <T> ChoiceRow(
    label: String,
    options: List<T>,
    selected: T,
    optionLabel: (T) -> String,
    onSelect: (T) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { option ->
                FilterChip(
                    selected = option == selected,
                    onClick = { onSelect(option) },
                    label = { Text(optionLabel(option)) }
                )
            }
        }
    }
}

@Composable
private fun ColorChoiceRow(
    label: String,
    selected: Long,
    colors: List<Long>,
    onSelect: (Long) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            colors.forEach { color ->
                FilterChip(
                    selected = color == selected,
                    onClick = { onSelect(color) },
                    label = {
                        Box(
                            Modifier.size(22.dp).background(Color(color), CircleShape)
                        )
                    }
                )
            }
        }
    }
}

private fun percent(value: Float): String = "${(value * 100).roundToInt()}%"
