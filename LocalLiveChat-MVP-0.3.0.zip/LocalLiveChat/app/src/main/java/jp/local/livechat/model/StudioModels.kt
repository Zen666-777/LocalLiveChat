package jp.local.livechat.model

enum class HairPreset(val label: String) {
    SHORT_BOB("ショートボブ"),
    LONG("ロング"),
    TWIN_TAIL("ツインテール")
}

enum class OutfitPreset(val label: String) {
    AQUA_STREET("水色ストリート"),
    LOUNGE("ルームウェア"),
    CYBER("サイバー")
}

data class AvatarDesign(
    val hairPreset: HairPreset = HairPreset.SHORT_BOB,
    val hairColorArgb: Long = 0xFFF1FBFF,
    val hairAccentArgb: Long = 0xFF73D5E8,
    val eyeColorArgb: Long = 0xFF47BBD7,
    val outfitPreset: OutfitPreset = OutfitPreset.AQUA_STREET,
    val outfitColorArgb: Long = 0xFF65CDE1
)

data class MotionSettings(
    val breathStrength: Float = 0.55f,
    val swayStrength: Float = 0.35f,
    val blinkSpeed: Float = 0.55f,
    val mouthStrength: Float = 0.75f
) {
    fun normalized() = copy(
        breathStrength = breathStrength.coerceIn(0f, 1f),
        swayStrength = swayStrength.coerceIn(0f, 1f),
        blinkSpeed = blinkSpeed.coerceIn(0f, 1f),
        mouthStrength = mouthStrength.coerceIn(0f, 1f)
    )
}

data class GenerationSettings(
    val maxTokens: Int = 320,
    val temperature: Float = 0.85f
) {
    fun normalized() = copy(
        maxTokens = maxTokens.coerceIn(64, 1024),
        temperature = temperature.coerceIn(0.1f, 1.5f)
    )
}

data class StudioProject(
    val character: CharacterProfile = BuiltInCharacters.Meru,
    val avatarDesign: AvatarDesign = AvatarDesign(),
    val motion: MotionSettings = MotionSettings(),
    val generation: GenerationSettings = GenerationSettings()
) {
    fun normalized(): StudioProject {
        val adultPersona = character.persona.copy(age = character.persona.age.coerceIn(18, 99))
        return copy(
            character = character.copy(
                persona = adultPersona,
                voice = character.voice.copy(
                    speechRate = character.voice.speechRate.coerceIn(0.5f, 1.5f),
                    pitch = character.voice.pitch.coerceIn(0.5f, 1.5f)
                )
            ),
            motion = motion.normalized(),
            generation = generation.normalized()
        )
    }
}
