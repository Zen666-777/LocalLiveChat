package jp.local.livechat

import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import jp.local.livechat.data.ConversationStore
import jp.local.livechat.data.StudioStore
import jp.local.livechat.engine.DemoAndLlamaEngine
import jp.local.livechat.speech.SpeechController
import jp.local.livechat.ui.StudioApp

class MainActivity : ComponentActivity() {
    private val engine = DemoAndLlamaEngine()
    private lateinit var speech: SpeechController
    private var speaking by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speech = SpeechController(this) { value -> runOnUiThread { speaking = value } }
        val store = ConversationStore(this)
        val studioStore = StudioStore(this)

        setContent {
            val isSpeaking = speaking
            var project by remember { mutableStateOf(studioStore.load()) }
            val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri == null) return@rememberLauncherForActivityResult
                lifecycleScope.launch {
                    Toast.makeText(this@MainActivity, "モデルを読み込んでいます…", Toast.LENGTH_SHORT).show()
                    val result = runCatching {
                        val modelName = contentResolver.query(
                            uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
                        )?.use { cursor ->
                            if (cursor.moveToFirst()) cursor.getString(0) else null
                        } ?: "local-model.gguf"
                        contentResolver.openFileDescriptor(uri, "r").use { descriptor ->
                            requireNotNull(descriptor) { "モデルを開けません" }
                            engine.loadModel("/proc/self/fd/${descriptor.fd}", modelName).getOrThrow()
                        }
                    }
                    Toast.makeText(
                        this@MainActivity,
                        result.fold({ "GGUFを読み込みました" }, { "読込失敗: ${it.message}" }),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            val avatarImportPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri == null) return@rememberLauncherForActivityResult
                val result = runCatching {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    requireNotNull(raw) { "ファイルを開けません" }
                    studioStore.import(raw)
                }
                result.onSuccess { imported ->
                    project = imported
                    studioStore.save(imported)
                }
                Toast.makeText(
                    this@MainActivity,
                    result.fold({ "キャラクターを読み込みました" }, { "読込失敗: ${it.message}" }),
                    Toast.LENGTH_LONG
                ).show()
            }
            val avatarExportPicker = rememberLauncherForActivityResult(
                ActivityResultContracts.CreateDocument("application/json")
            ) { uri ->
                if (uri == null) return@rememberLauncherForActivityResult
                val result = runCatching {
                    contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                        it.write(studioStore.export(project))
                    } ?: error("保存先を開けません")
                }
                Toast.makeText(
                    this@MainActivity,
                    result.fold({ "キャラクターを保存しました" }, { "保存失敗: ${it.message}" }),
                    Toast.LENGTH_LONG
                ).show()
            }

            StudioApp(
                engine = engine,
                store = store,
                speech = speech,
                speaking = isSpeaking,
                project = project,
                onProjectChange = { updated ->
                    project = updated.normalized()
                    studioStore.save(project)
                },
                onChooseModel = { modelPicker.launch(arrayOf("application/octet-stream", "*/*")) },
                onImportProject = { avatarImportPicker.launch(arrayOf("application/json", "*/*")) },
                onExportProject = {
                    val safeName = project.character.persona.name.ifBlank { "character" }
                        .replace(Regex("[^A-Za-z0-9ぁ-んァ-ヶ一-龠_-]"), "_")
                    avatarExportPicker.launch("$safeName.mavatar")
                }
            )
        }
    }

    override fun onDestroy() {
        engine.close()
        speech.shutdown()
        super.onDestroy()
    }
}
