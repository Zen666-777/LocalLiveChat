package jp.local.livechat.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import jp.local.livechat.avatar.AvatarRenderState
import jp.local.livechat.model.Emotion
import jp.local.livechat.model.HairPreset
import jp.local.livechat.model.OutfitPreset
import kotlin.math.PI
import kotlin.math.sin

/** スマホ内キャラメイク用の軽量2Dレンダラー。設定変更を即時プレビューする。 */
@Composable
fun AvatarSurface(state: AvatarRenderState, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "avatar")
    val breathe by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe"
    )
    val sway by transition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "sway"
    )
    val blinkPhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween((3800 - state.animation.blinkSpeed * 2100).toInt().coerceAtLeast(1200)),
            RepeatMode.Restart
        ),
        label = "blink"
    )
    val mouth by transition.animateFloat(
        initialValue = 0.08f,
        targetValue = if (state.speaking) state.animation.mouthStrength else 0.10f,
        animationSpec = infiniteRepeatable(tween(if (state.speaking) 125 else 900), RepeatMode.Reverse),
        label = "mouth"
    )

    val emotionAccent = when (state.emotion) {
        Emotion.SHY, Emotion.LOVING -> Color(0xFFFF80AB)
        Emotion.ANGRY -> Color(0xFFFF6B6B)
        Emotion.SAD -> Color(0xFF76A9DC)
        else -> Color(state.design.hairAccentArgb)
    }

    Box(
        modifier.background(
            Brush.verticalGradient(listOf(Color(0xFF183E4B), Color(0xFF0A1B24)))
        )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val unit = size.minDimension / 500f
            val cx = size.width / 2f
            val breathOffset = breathe * 5f * unit * state.animation.breathStrength
            val headY = size.height * 0.38f + breathOffset
            val blink = if (blinkPhase > 0.91f) {
                sin(((blinkPhase - 0.91f) / 0.09f * PI).toFloat()).coerceIn(0f, 1f)
            } else 0f
            val hair = Color(state.design.hairColorArgb)
            val hairShadow = Color(state.design.hairAccentArgb).copy(alpha = 0.55f)
            val eyes = Color(state.design.eyeColorArgb)
            val outfit = Color(state.design.outfitColorArgb)

            drawCircle(emotionAccent.copy(alpha = 0.15f), 190f * unit, Offset(cx, headY))

            rotate(sway * 1.8f * state.animation.swayStrength, Offset(cx, headY)) {
                when (state.design.hairPreset) {
                    HairPreset.SHORT_BOB -> drawOval(
                        hair, Offset(cx - 166f * unit, headY - 178f * unit), Size(332f * unit, 386f * unit)
                    )
                    HairPreset.LONG -> drawOval(
                        hair, Offset(cx - 170f * unit, headY - 180f * unit), Size(340f * unit, 560f * unit)
                    )
                    HairPreset.TWIN_TAIL -> {
                        drawOval(hair, Offset(cx - 232f * unit, headY - 70f * unit), Size(105f * unit, 330f * unit))
                        drawOval(hair, Offset(cx + 127f * unit, headY - 70f * unit), Size(105f * unit, 330f * unit))
                        drawOval(hair, Offset(cx - 166f * unit, headY - 178f * unit), Size(332f * unit, 390f * unit))
                    }
                }

                drawRoundRect(
                    Color(0xFFFFE4DE),
                    Offset(cx - 33f * unit, headY + 105f * unit),
                    Size(66f * unit, 88f * unit),
                    CornerRadius(18f * unit)
                )
                val bodyTop = headY + 157f * unit
                drawOval(outfit, Offset(cx - 176f * unit, bodyTop), Size(352f * unit, size.height * 0.55f))
                if (state.design.outfitPreset == OutfitPreset.AQUA_STREET) {
                    drawLine(Color.White.copy(alpha = 0.9f), Offset(cx - 130f * unit, bodyTop + 25f * unit), Offset(cx - 158f * unit, bodyTop + 165f * unit), 8f * unit)
                    drawLine(Color.White.copy(alpha = 0.9f), Offset(cx + 130f * unit, bodyTop + 25f * unit), Offset(cx + 158f * unit, bodyTop + 165f * unit), 8f * unit)
                } else if (state.design.outfitPreset == OutfitPreset.CYBER) {
                    drawLine(emotionAccent, Offset(cx - 120f * unit, bodyTop + 70f * unit), Offset(cx + 120f * unit, bodyTop + 70f * unit), 5f * unit)
                }

                drawOval(Color(0xFFFFE7E1), Offset(cx - 125f * unit, headY - 125f * unit), Size(250f * unit, 278f * unit))

                val bangs = Path().apply {
                    moveTo(cx - 128f * unit, headY - 112f * unit)
                    quadraticBezierTo(cx - 82f * unit, headY - 192f * unit, cx, headY - 164f * unit)
                    quadraticBezierTo(cx + 96f * unit, headY - 190f * unit, cx + 128f * unit, headY - 108f * unit)
                    lineTo(cx + 89f * unit, headY - 32f * unit)
                    lineTo(cx + 40f * unit, headY - 80f * unit)
                    lineTo(cx + 5f * unit, headY - 22f * unit)
                    lineTo(cx - 36f * unit, headY - 84f * unit)
                    lineTo(cx - 92f * unit, headY - 31f * unit)
                    close()
                }
                drawPath(bangs, hair)
                drawOval(hairShadow, Offset(cx + 76f * unit, headY - 140f * unit), Size(21f * unit, 126f * unit))
                drawCircle(Color(state.design.hairAccentArgb), 11f * unit, Offset(cx - 107f * unit, headY - 73f * unit))

                val eyeHeight = (24f * (1f - blink)).coerceAtLeast(2.5f) * unit
                val eyeY = headY - 20f * unit
                drawOval(eyes, Offset(cx - 78f * unit, eyeY), Size(38f * unit, eyeHeight))
                drawOval(eyes, Offset(cx + 40f * unit, eyeY), Size(38f * unit, eyeHeight))
                if (blink < 0.65f) {
                    drawCircle(Color.White.copy(alpha = 0.92f), 5f * unit, Offset(cx - 52f * unit, eyeY + 6f * unit))
                    drawCircle(Color.White.copy(alpha = 0.92f), 5f * unit, Offset(cx + 66f * unit, eyeY + 6f * unit))
                }

                if (state.emotion == Emotion.SHY || state.emotion == Emotion.LOVING) {
                    drawCircle(Color(0xFFFF8EA8).copy(alpha = 0.34f), 22f * unit, Offset(cx - 84f * unit, eyeY + 61f * unit))
                    drawCircle(Color(0xFFFF8EA8).copy(alpha = 0.34f), 22f * unit, Offset(cx + 84f * unit, eyeY + 61f * unit))
                }

                drawOval(
                    Color(0xFFB44769),
                    Offset(cx - 22f * unit, eyeY + 78f * unit),
                    Size(44f * unit, (7f + 27f * mouth) * unit)
                )
                drawCircle(emotionAccent, 10f * unit, Offset(cx, bodyTop + 28f * unit))
            }
        }
    }
}
