package jp.local.livechat.speech

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID
import jp.local.livechat.model.VoiceProfile

class SpeechController(
    context: Context,
    private val onSpeakingChanged: (Boolean) -> Unit
) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var profile = VoiceProfile()

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = onSpeakingChanged(true)
            override fun onDone(utteranceId: String?) = onSpeakingChanged(false)
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = onSpeakingChanged(false)
        })
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) {
            applyVoiceProfile()
        }
    }

    fun configure(newProfile: VoiceProfile) {
        profile = newProfile
        if (ready) applyVoiceProfile()
    }

    private fun applyVoiceProfile() {
        tts.language = Locale.forLanguageTag(profile.localeTag)
        tts.setSpeechRate(profile.speechRate)
        tts.setPitch(profile.pitch)
        profile.preferredVoiceId?.let { voiceId ->
            tts.voices?.firstOrNull { it.name == voiceId }?.let { tts.voice = it }
        }
    }

    fun speak(text: String) {
        if (!ready) return
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), UUID.randomUUID().toString())
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
