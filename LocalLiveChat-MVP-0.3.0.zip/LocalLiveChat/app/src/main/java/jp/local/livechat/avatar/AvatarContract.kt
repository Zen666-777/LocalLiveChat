package jp.local.livechat.avatar

import jp.local.livechat.model.AvatarProfile
import jp.local.livechat.model.AvatarDesign
import jp.local.livechat.model.Emotion
import jp.local.livechat.model.MotionSettings

/**
 * Cubism SDKをこの契約へ接続する。SDK/Core/モデルデータは各ライセンスに従って別途追加する。
 */
interface AvatarDriver {
    fun loadProfile(profile: AvatarProfile)
    fun setEmotion(emotion: Emotion)
    fun playMotion(group: String)
    fun setMouthOpen(value: Float)
}

data class AvatarRenderState(
    val emotion: Emotion = Emotion.HAPPY,
    val motion: String = "idle",
    val speaking: Boolean = false,
    val profile: AvatarProfile = AvatarProfile(),
    val design: AvatarDesign = AvatarDesign(),
    val animation: MotionSettings = MotionSettings()
)
