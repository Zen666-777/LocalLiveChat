package jp.local.livechat.model

/**
 * 会話人格・Live2D・音声・配色を一つに束ねた差し替え単位。
 * 将来のキャラメイク画面は、この値を編集して保存する。
 */
data class CharacterProfile(
    val id: String,
    val persona: Persona,
    val greeting: String,
    val inputHint: String,
    val avatar: AvatarProfile,
    val voice: VoiceProfile,
    val theme: CharacterTheme
)

data class AvatarProfile(
    val modelDirectory: String? = null,
    val modelJson: String? = null,
    val designTags: List<String> = emptyList(),
    val expressionFiles: Map<Emotion, String> = emptyMap(),
    val motionGroups: Map<String, String> = emptyMap()
)

data class VoiceProfile(
    val localeTag: String = "ja-JP",
    val speechRate: Float = 1.04f,
    val pitch: Float = 1.12f,
    val preferredVoiceId: String? = null
)

data class CharacterTheme(
    val primaryArgb: Long,
    val secondaryArgb: Long,
    val backgroundArgb: Long,
    val surfaceArgb: Long,
    val userBubbleArgb: Long,
    val characterBubbleArgb: Long,
    val mutedTextArgb: Long
)

object BuiltInCharacters {
    val Meru = CharacterProfile(
        id = "meru_default",
        persona = Persona(
            name = "メル",
            age = 22,
            relationship = "ご主人さまを慕う、甘え上手な専属パートナー",
            tone = "甘々で親しみ深い。自然な関西寄りの日本語も理解する"
        ),
        greeting = "おかえりなさい、ご主人さま。メル、待ってました。",
        inputHint = "メルに話しかける",
        avatar = AvatarProfile(
            designTags = listOf(
                "adult_22",
                "short_white_bob",
                "aqua_inner_hair",
                "slender_delicate",
                "oversized_aqua_track_jacket",
                "crystal_blue_eyes",
                "single_aqua_droplet_hairclip",
                "no_ear_jewelry"
            ),
            expressionFiles = Emotion.entries.associateWith { emotion ->
                "expressions/${emotion.name.lowercase()}.exp3.json"
            },
            motionGroups = mapOf(
                "idle" to "Idle",
                "nod" to "Nod",
                "look_away" to "Shy",
                "lean_in" to "LeanIn",
                "troubled" to "Troubled"
            )
        ),
        voice = VoiceProfile(),
        theme = CharacterTheme(
            primaryArgb = 0xFF73D5E8,
            secondaryArgb = 0xFFA8F0F5,
            backgroundArgb = 0xFF0D1B24,
            surfaceArgb = 0xFF152934,
            userBubbleArgb = 0xFF227A91,
            characterBubbleArgb = 0xFF193540,
            mutedTextArgb = 0xFFA5C6D0
        )
    )
}
