package jp.local.livechat.data

import android.content.Context
import jp.local.livechat.model.ChatMessage
import jp.local.livechat.model.Speaker
import org.json.JSONArray
import org.json.JSONObject

class ConversationStore(context: Context) {
    private val preferences = context.getSharedPreferences("private_conversation", Context.MODE_PRIVATE)

    fun load(characterId: String = "default"): List<ChatMessage> = runCatching {
        val key = messagesKey(characterId)
        val stored = preferences.getString(key, null)
            ?: preferences.getString("messages", "[]") // v0.2.0からの移行
        val array = JSONArray(stored)
        buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    ChatMessage(
                        id = item.getString("id"),
                        speaker = Speaker.valueOf(item.getString("speaker")),
                        text = item.getString("text"),
                        timestamp = item.getLong("timestamp")
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    fun save(messages: List<ChatMessage>, characterId: String = "default") {
        val array = JSONArray()
        messages.takeLast(100).forEach { message ->
            array.put(JSONObject().apply {
                put("id", message.id)
                put("speaker", message.speaker.name)
                put("text", message.text)
                put("timestamp", message.timestamp)
            })
        }
        preferences.edit().putString(messagesKey(characterId), array.toString()).apply()
    }

    fun clear(characterId: String) = preferences.edit().remove(messagesKey(characterId)).apply()

    fun clearAll() = preferences.edit().clear().apply()

    private fun messagesKey(characterId: String) = "messages.$characterId"
}
