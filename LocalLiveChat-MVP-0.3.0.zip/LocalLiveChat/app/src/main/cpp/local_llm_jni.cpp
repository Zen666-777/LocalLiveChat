#include <android/log.h>
#include <jni.h>
#include <algorithm>
#include <atomic>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "llama.h"

namespace {
constexpr uint32_t CONTEXT_SIZE = 4096;
constexpr uint32_t BATCH_SIZE = 256;
constexpr const char *LOG_TAG = "LocalLiveChatLLM";

std::mutex inference_mutex;
std::once_flag backend_once;
llama_model *model = nullptr;
llama_context *context = nullptr;
std::string last_error;
std::atomic<bool> cancel_requested{false};

void log_callback(ggml_log_level level, const char *text, void *) {
    const int priority = level >= GGML_LOG_LEVEL_ERROR ? ANDROID_LOG_ERROR
        : level == GGML_LOG_LEVEL_WARN ? ANDROID_LOG_WARN
        : ANDROID_LOG_DEBUG;
    __android_log_write(priority, LOG_TAG, text);
}

void set_error(const std::string &message) {
    last_error = message;
    __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, "%s", message.c_str());
}

jstring to_java_string(JNIEnv *env, const std::string &utf8) {
    jbyteArray bytes = env->NewByteArray(static_cast<jsize>(utf8.size()));
    if (!bytes) return nullptr;
    env->SetByteArrayRegion(
        bytes,
        0,
        static_cast<jsize>(utf8.size()),
        reinterpret_cast<const jbyte *>(utf8.data())
    );
    jclass string_class = env->FindClass("java/lang/String");
    jmethodID constructor = env->GetMethodID(string_class, "<init>", "([BLjava/lang/String;)V");
    jstring charset = env->NewStringUTF("UTF-8");
    auto result = static_cast<jstring>(env->NewObject(string_class, constructor, bytes, charset));
    env->DeleteLocalRef(charset);
    env->DeleteLocalRef(string_class);
    env->DeleteLocalRef(bytes);
    return result;
}

std::string from_java_string(JNIEnv *env, jstring value) {
    if (!value) return {};
    jclass string_class = env->GetObjectClass(value);
    jmethodID get_bytes = env->GetMethodID(string_class, "getBytes", "(Ljava/lang/String;)[B");
    jstring charset = env->NewStringUTF("UTF-8");
    auto bytes = static_cast<jbyteArray>(env->CallObjectMethod(value, get_bytes, charset));
    const jsize length = env->GetArrayLength(bytes);
    std::string result(static_cast<size_t>(length), '\0');
    env->GetByteArrayRegion(
        bytes, 0, length, reinterpret_cast<jbyte *>(result.data())
    );
    env->DeleteLocalRef(bytes);
    env->DeleteLocalRef(charset);
    env->DeleteLocalRef(string_class);
    return result;
}

void unload_locked() {
    if (context) {
        llama_free(context);
        context = nullptr;
    }
    if (model) {
        llama_model_free(model);
        model = nullptr;
    }
}

std::string apply_chat_template(const std::string &system, const std::string &conversation) {
    const char *chat_template = llama_model_chat_template(model, nullptr);
    if (!chat_template) {
        return "### System:\n" + system + "\n\n### User:\n" + conversation +
               "\n\n### Assistant:\n";
    }

    const llama_chat_message messages[] = {
        {"system", system.c_str()},
        {"user", conversation.c_str()},
    };
    int32_t required = llama_chat_apply_template(
        chat_template, messages, 2, true, nullptr, 0
    );
    if (required <= 0) {
        return "### System:\n" + system + "\n\n### User:\n" + conversation +
               "\n\n### Assistant:\n";
    }
    std::vector<char> formatted(static_cast<size_t>(required) + 1);
    int32_t written = llama_chat_apply_template(
        chat_template, messages, 2, true, formatted.data(), static_cast<int32_t>(formatted.size())
    );
    if (written < 0) {
        return "### System:\n" + system + "\n\n### User:\n" + conversation +
               "\n\n### Assistant:\n";
    }
    return std::string(formatted.data(), static_cast<size_t>(written));
}

bool tokenize_prompt(const std::string &prompt, int max_tokens, std::vector<llama_token> &tokens) {
    const llama_vocab *vocab = llama_model_get_vocab(model);
    int32_t count = -llama_tokenize(
        vocab, prompt.data(), static_cast<int32_t>(prompt.size()), nullptr, 0, true, true
    );
    if (count <= 0) {
        set_error("プロンプトのトークン化に失敗しました");
        return false;
    }
    tokens.resize(static_cast<size_t>(count));
    if (llama_tokenize(
            vocab,
            prompt.data(),
            static_cast<int32_t>(prompt.size()),
            tokens.data(),
            static_cast<int32_t>(tokens.size()),
            true,
            true
        ) < 0) {
        set_error("プロンプトのトークン化に失敗しました");
        return false;
    }

    const size_t max_prompt = CONTEXT_SIZE - static_cast<size_t>(max_tokens) - 8;
    if (tokens.size() > max_prompt) {
        const size_t keep_head = std::min<size_t>(512, max_prompt / 4);
        std::vector<llama_token> shortened;
        shortened.reserve(max_prompt);
        shortened.insert(shortened.end(), tokens.begin(), tokens.begin() + keep_head);
        shortened.insert(shortened.end(), tokens.end() - (max_prompt - keep_head), tokens.end());
        tokens.swap(shortened);
    }
    return true;
}

bool decode_prompt(const std::vector<llama_token> &tokens) {
    for (size_t offset = 0; offset < tokens.size(); offset += BATCH_SIZE) {
        const int32_t count = static_cast<int32_t>(
            std::min<size_t>(BATCH_SIZE, tokens.size() - offset)
        );
        llama_batch batch = llama_batch_get_one(
            const_cast<llama_token *>(tokens.data() + offset), count
        );
        const int result = llama_decode(context, batch);
        if (result != 0) {
            set_error("プロンプト処理に失敗しました: " + std::to_string(result));
            return false;
        }
    }
    return true;
}

std::string token_piece(llama_token token) {
    const llama_vocab *vocab = llama_model_get_vocab(model);
    std::vector<char> buffer(256);
    int32_t length = llama_token_to_piece(
        vocab, token, buffer.data(), static_cast<int32_t>(buffer.size()), 0, true
    );
    if (length < 0) {
        buffer.resize(static_cast<size_t>(-length));
        length = llama_token_to_piece(
            vocab, token, buffer.data(), static_cast<int32_t>(buffer.size()), 0, true
        );
    }
    return length > 0 ? std::string(buffer.data(), static_cast<size_t>(length)) : std::string();
}
} // namespace

extern "C" JNIEXPORT jboolean JNICALL
Java_jp_local_livechat_engine_LlamaCppBridge_loadModel(
    JNIEnv *env, jobject, jstring model_path
) {
    std::lock_guard<std::mutex> lock(inference_mutex);
    std::call_once(backend_once, [] {
        llama_log_set(log_callback, nullptr);
        ggml_backend_load_all();
        llama_backend_init();
    });
    unload_locked();
    last_error.clear();
    cancel_requested.store(false);

    const std::string path = from_java_string(env, model_path);
    llama_model_params model_params = llama_model_default_params();
    model_params.n_gpu_layers = 0;
    model_params.load_mode = LLAMA_LOAD_MODE_MMAP;
    model = llama_model_load_from_file(path.c_str(), model_params);
    if (!model) {
        set_error("GGUFモデルを開けませんでした。対応形式と空きRAMを確認してください");
        return JNI_FALSE;
    }

    llama_context_params context_params = llama_context_default_params();
    const unsigned int cores = std::max(2u, std::thread::hardware_concurrency());
    const int threads = static_cast<int>(std::min(4u, cores > 2 ? cores - 2 : cores));
    context_params.n_ctx = CONTEXT_SIZE;
    context_params.n_batch = BATCH_SIZE;
    context_params.n_ubatch = BATCH_SIZE;
    context_params.n_threads = threads;
    context_params.n_threads_batch = threads;
    context_params.no_perf = true;
    context = llama_init_from_model(model, context_params);
    if (!context) {
        set_error("推論コンテキストを確保できませんでした。より小さいモデルを試してください");
        unload_locked();
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_jp_local_livechat_engine_LlamaCppBridge_generate(
    JNIEnv *env,
    jobject,
    jstring system_prompt,
    jstring conversation,
    jint max_tokens,
    jfloat temperature
) {
    std::lock_guard<std::mutex> lock(inference_mutex);
    last_error.clear();
    cancel_requested.store(false);
    if (!model || !context) {
        set_error("モデルが読み込まれていません");
        return to_java_string(env, "");
    }

    const int predict = std::clamp(static_cast<int>(max_tokens), 16, 1024);
    const float temp = std::clamp(static_cast<float>(temperature), 0.05f, 2.0f);
    const std::string prompt = apply_chat_template(
        from_java_string(env, system_prompt), from_java_string(env, conversation)
    );
    std::vector<llama_token> prompt_tokens;
    if (!tokenize_prompt(prompt, predict, prompt_tokens)) {
        return to_java_string(env, "");
    }

    llama_memory_clear(llama_get_memory(context), false);
    if (!decode_prompt(prompt_tokens)) {
        return to_java_string(env, "");
    }

    llama_sampler *sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_min_p(0.05f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(temp));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    std::string response;
    const llama_vocab *vocab = llama_model_get_vocab(model);
    for (int index = 0; index < predict && !cancel_requested.load(); ++index) {
        const llama_token token = llama_sampler_sample(sampler, context, -1);
        llama_sampler_accept(sampler, token);
        if (llama_vocab_is_eog(vocab, token)) break;

        response += token_piece(token);
        llama_token decoded_token = token;
        llama_batch batch = llama_batch_get_one(&decoded_token, 1);
        const int result = llama_decode(context, batch);
        if (result != 0) {
            set_error("応答生成に失敗しました: " + std::to_string(result));
            break;
        }
    }
    llama_sampler_free(sampler);
    return to_java_string(env, response);
}

extern "C" JNIEXPORT void JNICALL
Java_jp_local_livechat_engine_LlamaCppBridge_cancel(JNIEnv *, jobject) {
    cancel_requested.store(true);
}

extern "C" JNIEXPORT void JNICALL
Java_jp_local_livechat_engine_LlamaCppBridge_unload(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(inference_mutex);
    unload_locked();
    cancel_requested.store(false);
}

extern "C" JNIEXPORT jstring JNICALL
Java_jp_local_livechat_engine_LlamaCppBridge_lastError(JNIEnv *env, jobject) {
    std::lock_guard<std::mutex> lock(inference_mutex);
    return to_java_string(env, last_error);
}
