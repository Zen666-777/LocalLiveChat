package jp.local.livechat.engine

import jp.local.livechat.model.Emotion
import org.junit.Assert.assertEquals
import org.junit.Test

class StructuredResponseParserTest {
    @Test
    fun parsesJsonWrappedInText() {
        val result = StructuredResponseParser.parse(
            "```json\n{\"speech\":\"おかえり\",\"emotion\":\"SHY\",\"motion\":\"wave\",\"intimacy_delta\":2}\n```"
        )
        assertEquals("おかえり", result.speech)
        assertEquals(Emotion.SHY, result.emotion)
        assertEquals("wave", result.motion)
        assertEquals(2, result.intimacyDelta)
    }

    @Test
    fun fallsBackToPlainSpeech() {
        val result = StructuredResponseParser.parse("こんにちは")
        assertEquals("こんにちは", result.speech)
        assertEquals(Emotion.NEUTRAL, result.emotion)
    }
}
