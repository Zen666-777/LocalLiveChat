# Third-party notices

## llama.cpp

- Project: `ggml-org/llama.cpp`
- Included commit: `d222767c7a6516559a3f49e7721b6c6b1acc87b4`
- Snapshot date: 2026-08-25
- License: MIT
- Source location: `app/src/main/cpp/vendor/llama.cpp`
- License text: `app/src/main/cpp/vendor/llama.cpp/LICENSE`

llama.cpp本体への変更は行っていません。アプリ固有のJNIとCMake設定は、その外側に配置しています。
