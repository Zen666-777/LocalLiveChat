# メル Live2D制作仕様 v1

## 現在地

このフォルダの画像は、Cubismへ直接読み込める完成PSDではなく、承認済みデザインを固定するための制作資料です。

- `../meru-face-approved-v1.png`: 顔・表情・髪色の承認基準（ピアスなし）
- `../meru-model-sheet-v1.png`: 衣装・体型・前後側面の承認基準
- `meru-front-reference-v1.png`: 正面ポーズと比率の基準。背景の市松模様は画像に焼き込まれており、透過素材ではありません

本番では、以下の仕様に沿って4096×8192px以上のレイヤー付きPSDへ描き起こします。背景レイヤーは作らず、各パーツ外側へ変形用の塗り足しを入れます。

## 変更禁止の承認事項

| 項目 | 仕様 |
|---|---|
| 年齢 | 22歳の成人女性 |
| 顔 | 短い下顔面、柔らかい頬、小さな顎、太い上まつ毛 |
| 瞳 | 青→水色→薄紫の高彩度グラデーション、左右同一のハイライト構成 |
| 髪 | 真珠白の顎丈ボブ、水色インナー、右側の雫型ヘアピン |
| 耳 | 裸耳。ピアス、イヤリング、イヤーカフを付けない |
| 体型 | 華奢、肩幅と腰幅は狭め、胸は控えめ、脚は細長い |
| 衣装 | 白トップス、白×水色の大きめジャケット、薄灰色ショートパンツ、白×水色スニーカー |
| 装飾 | 雫型ヘアピンと衣装の雫型ジッパーのみ。首・手・耳の装飾なし |

## 推奨PSD階層

上にあるものほど手前に描画します。`L`と`R`はキャラクター本人から見た左右です。

| グループ | 必須レイヤー | 分割・塗り足し要件 |
|---|---|---|
| FRONT_HAIR | `Hair_Front_Center_01..05`, `Hair_Front_L_01..03`, `Hair_Front_R_01..03`, `Hair_Side_L`, `Hair_Side_R`, `Hair_Pin_Drop` | 房ごとに根元まで描く。眉・目の上を隠す房も裏側を描く |
| FACE_DETAIL | `Brow_L/R`, `UpperLash_L/R`, `LowerLash_L/R`, `EyeWhite_L/R`, `Iris_L/R`, `Pupil_L/R`, `EyeHighlight_L/R`, `EyeShadow_L/R`, `Nose`, `Blush_L/R` | 白目と虹彩は閉眼時に隠れる範囲も描く。ハイライトは虹彩と別 |
| MOUTH | `Mouth_Line_Upper/Lower`, `Mouth_Inner`, `Teeth_Upper`, `Tongue`, `Lip_Mask` | `ParamMouthOpenY`と`ParamMouthForm`を独立させる。閉口線を別にする |
| FACE_BASE | `Face_Skin`, `Ear_L/R`, `Neck`, `Face_Shadow` | 前髪下、顎下、耳の奥まで十分に塗り足す |
| BACK_HAIR | `Hair_Back_Base`, `Hair_Back_L_01..04`, `Hair_Back_R_01..04`, `Hair_Aqua_Under_L/R` | 首とジャケットで隠れる範囲も描く。水色インナーは白髪と別 |
| JACKET_FRONT | `Jacket_Body_L/R`, `Jacket_Collar_L/R`, `Jacket_Lapel_L/R`, `Jacket_Hem_L/R`, `Jacket_Zip_L/R`, `Zip_Drop_L/R`, `Pocket_L/R` | 胴体回転用に左右分割。開口部の内側と裏地を描く |
| ARMS | `UpperArm_L/R`, `Forearm_L/R`, `SleeveUpper_L/R`, `SleeveLower_L/R`, `Cuff_L/R`, `Hand_L/R` | 肩、肘、手首の下を塗り足す。袖と素手を分離 |
| INNER_TOP | `Top_Body`, `Top_Shadow`, `Top_Hem` | ジャケット下の隠れる胴体全体まで描く |
| LOWER_BODY | `Waist`, `Shorts_Front_L/R`, `Shorts_Back`, `Shorts_Belt`, `Thigh_L/R`, `Knee_L/R`, `Shin_L/R` | 脚は左右完全分離。ショートパンツ下の腰・脚も描く |
| FEET | `Sock_L/R`, `Shoe_L/R`, `ShoeLace_L/R`, `ShoeAccent_L/R`, `Sole_L/R` | 足首回転用に靴下・靴を分け、靴紐は必要に応じて統合 |

### 最低レイヤー数

顔・髪・衣装・身体を含めて80レイヤー以上を目安とします。髪揺れとジャケット袖揺れを滑らかにする場合は100〜130レイヤーを推奨します。

## 標準パラメータ

| Cubism ID | 範囲 | 用途 |
|---|---:|---|
| `ParamAngleX` | -30..30 | 顔の左右向き |
| `ParamAngleY` | -30..30 | 顔の上下向き |
| `ParamAngleZ` | -30..30 | 首かしげ |
| `ParamBodyAngleX` | -10..10 | 上体左右 |
| `ParamBodyAngleY` | -10..10 | 上体前後 |
| `ParamBodyAngleZ` | -10..10 | 上体傾き |
| `ParamEyeLOpen`, `ParamEyeROpen` | 0..1 | まばたき |
| `ParamEyeBallX`, `ParamEyeBallY` | -1..1 | 視線 |
| `ParamBrowLY/RY` | -1..1 | 眉上下 |
| `ParamBrowLForm/RForm` | -1..1 | 眉形状 |
| `ParamMouthOpenY` | 0..1 | TTS口パク |
| `ParamMouthForm` | -1..1 | 不機嫌↔笑顔 |
| `ParamCheek` | 0..1 | 赤面 |
| `ParamBreath` | 0..1 | 呼吸 |
| `ParamHairFront`, `ParamHairSide`, `ParamHairBack` | -1..1 | 髪物理演算入力 |
| `ParamJacketSleeveL/R` | -1..1 | 袖の遅れ揺れ |
| `ParamJacketHem` | -1..1 | 裾の遅れ揺れ |
| `ParamZipDropL/R` | -1..1 | 雫ジッパーの揺れ |

## アプリ感情との対応

| アプリ値 | 表情ファイル | 主な値 |
|---|---|---|
| `NEUTRAL` | `neutral.exp3.json` | 口角0.1、頬0.1 |
| `HAPPY` | `happy.exp3.json` | 口角0.7、目開き0.85 |
| `SHY` | `shy.exp3.json` | 頬0.9、視線下、口角0.25 |
| `LOVING` | `loving.exp3.json` | 半目、頬0.55、口角0.45 |
| `SAD` | `sad.exp3.json` | 眉内側上、口角-0.45 |
| `ANGRY` | `angry.exp3.json` | 眉内側下、口角-0.6、目開き0.9 |
| `SURPRISED` | `surprised.exp3.json` | 目開き1.0、口開き0.45 |

## モーション

| アプリ値 | Cubismグループ | 内容 |
|---|---|---|
| `idle` | `Idle` | 呼吸、微細な視線、髪と袖の物理演算 |
| `nod` | `Nod` | 小さく一度うなずく |
| `look_away` | `Shy` | 視線を外して頬を上げる |
| `lean_in` | `LeanIn` | 上体をわずかに近づける |
| `troubled` | `Troubled` | 眉を下げ、顔を少し傾ける |

## 物理演算グループ

1. 前髪: `AngleX`と`AngleZ`を入力、短い遅延
2. 横髪: `AngleX/Y/Z`を入力、中程度の遅延
3. 後髪と水色インナー: `AngleX/Y/Z`を入力、横髪より長い遅延
4. ジャケット袖: `BodyAngleX/Z`と腕角度を入力、重めの減衰
5. ジャケット裾: `BodyAngleX/Y`を入力、小さな振幅
6. 雫ジッパー: `BodyAngleX/Z`を入力、軽く速い振り子

## 書き出しと受け入れ条件

- PSDはRGB、sRGB、背景なし。全パーツを原寸で保持する
- Cubism Editor 5系で読み込み、テクスチャアトラスは最大4096pxを複数枚使用する
- 正面で継ぎ目が見えないこと。顔角度±30°で塗り足し不足が出ないこと
- 60fpsで自動まばたき・呼吸・髪・袖・裾・ジッパーが破綻しないこと
- `ParamMouthOpenY`単独で0→1へ動かしたとき、歯・舌・口内の表示順が正しいこと
- すべての表情でピアスや耳装飾が表示されないこと
- 最終納品物は`.cmo3`, `.moc3`, `.model3.json`, `.physics3.json`, `.pose3.json`, `.motion3.json`, `.exp3.json`, テクスチャPNG、元PSD

