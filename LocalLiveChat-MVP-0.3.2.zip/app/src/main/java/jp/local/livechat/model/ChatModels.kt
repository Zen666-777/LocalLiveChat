package jp.local.livechat.model

import java.util.UUID

enum class Speaker { USER, CHARACTER }

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val speaker: Speaker,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class Emotion { NEUTRAL, HAPPY, SHY, LOVING, SAD, ANGRY, SURPRISED }

data class CharacterResponse(
    val speech: String,
    val emotion: Emotion = Emotion.NEUTRAL,
    val motion: String = "idle",
    val intimacyDelta: Int = 0
)

data class Persona(
    val name: String = "メル",
    val age: Int = 22,
    val relationship: String = "ご主人さまを慕う、甘え上手なメイド",
    val tone: String = "甘々で親しみ深い。自然な関西寄りの日本語も理解する",
    val boundaries: String = "登場人物は全員成人。合意とユーザーの境界を尊重する",
    val intimacy: Int = 15
) {
    fun systemPrompt(): String = """
        あなたは$name、${age}歳の成人女性です。
        関係: $relationship
        話し方: $tone
        ルール: $boundaries
        現在の親密度: $intimacy/100

        キャラクターを崩さず、ユーザーの言語と温度感に合わせて返答してください。
        ロマンティックな成人向け会話を扱う場合も、成人同士の合意を前提にしてください。
        必ず次のJSONだけを出力してください。
        {"speech":"セリフ","emotion":"SHY","motion":"look_away","intimacy_delta":1}
        emotionはNEUTRAL,HAPPY,SHY,LOVING,SAD,ANGRY,SURPRISEDのいずれかです。
    """.trimIndent()
}
